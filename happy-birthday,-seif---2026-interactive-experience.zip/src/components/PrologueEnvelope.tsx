import { motion } from 'motion/react';
import { Sparkles, Heart, Compass, Volume2, ArrowRight } from 'lucide-react';
import { GreetingConfig } from '../types';
import { soundEngine } from '../utils/audio';

interface PrologueEnvelopeProps {
  config: GreetingConfig;
  onOpen: () => void;
  isAudioMuted: boolean;
  onToggleAudio: () => void;
}

export default function PrologueEnvelope({
  config,
  onOpen,
  isAudioMuted,
  onToggleAudio,
}: PrologueEnvelopeProps) {
  const handleSealClick = () => {
    soundEngine.playUnwrapSound();
    if (isAudioMuted) {
      onToggleAudio();
    } else {
      soundEngine.startAmbient();
    }
    setTimeout(() => {
      onOpen();
    }, 450);
  };

  const getRelationshipBadge = () => {
    switch (config.relationship) {
      case 'crush':
        return 'To Someone Unforgettable';
      case 'partner':
        return 'To My Favorite Person in the Universe 🤍';
      case 'best_friend':
        return 'To My Ride or Die';
      default:
        return 'To Someone Incredibly Rare 🤍';
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-12 relative z-10">
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-xl relative"
      >
        {/* Outer royal purple glow halo */}
        <div className="absolute -inset-1.5 bg-gradient-to-r from-purple-600/35 via-violet-500/25 to-fuchsia-500/25 rounded-[30px] blur-2xl opacity-85 animate-pulse-glow" />

        <div className="relative bg-[#0d1020]/90 border border-purple-500/30 backdrop-blur-2xl rounded-[26px] p-8 md:p-12 shadow-2xl overflow-hidden text-center">
          {/* Subtle celestial pattern decoration */}
          <div className="absolute top-0 right-0 w-72 h-72 bg-radial from-purple-600/15 to-transparent pointer-events-none -mr-24 -mt-24" />
          <div className="absolute bottom-0 left-0 w-72 h-72 bg-radial from-violet-600/15 to-transparent pointer-events-none -ml-24 -mb-24" />

          {/* Top Eyebrow Tag */}
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-500/15 border border-purple-500/30 text-purple-300 text-xs font-semibold tracking-wider uppercase mb-6 shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>{getRelationshipBadge()}</span>
          </motion.div>

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="font-serif-luxury text-4xl sm:text-5xl md:text-6xl font-semibold tracking-tight text-white mb-4 leading-tight"
          >
            Happy Birthday, <br />
            <span className="bg-gradient-to-r from-purple-300 via-violet-200 to-fuchsia-200 bg-clip-text text-transparent drop-shadow-sm">
              {config.recipientName}
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-purple-200/80 text-base sm:text-lg max-w-md mx-auto mb-8 font-sans-clean leading-relaxed"
          >
            {config.ageDisplay} &bull; {config.nickname}
          </motion.p>

          {/* Interactive Wax Seal / Luminous Key */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.5, type: 'spring', damping: 15 }}
            className="my-8 flex flex-col items-center"
          >
            <button
              onClick={handleSealClick}
              className="group relative w-20 h-20 sm:w-24 sm:h-24 rounded-full flex items-center justify-center bg-gradient-to-br from-purple-700 via-violet-800 to-purple-950 shadow-2xl shadow-purple-950/70 hover:scale-105 active:scale-95 transition-all duration-300 border-2 border-purple-400/50 cursor-pointer"
              title="Click to break seal & begin"
            >
              {/* Outer pulsing ring */}
              <div className="absolute -inset-2 rounded-full border border-purple-400/40 animate-ping opacity-35" />
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full border border-amber-300/40 flex items-center justify-center bg-purple-900/60 backdrop-blur-xs">
                <Heart className="w-7 h-7 sm:w-8 sm:h-8 text-purple-200 group-hover:scale-110 transition-transform fill-purple-300/20" />
              </div>
            </button>
            <span className="text-xs text-purple-300/80 mt-3 font-medium tracking-wide uppercase">
              Tap the wax seal to unlock
            </span>
          </motion.div>

          {/* Action button & Audio clue */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2"
          >
            <button
              onClick={handleSealClick}
              className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white font-medium text-sm tracking-wide shadow-lg shadow-purple-600/35 hover:shadow-purple-600/55 flex items-center justify-center gap-2 cursor-pointer transition-all duration-300"
            >
              <span>Begin Your Birthday Journey</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onToggleAudio}
              className="px-4 py-3 rounded-full bg-white/5 hover:bg-white/10 border border-purple-500/25 text-xs text-purple-200 flex items-center gap-2 transition-all cursor-pointer"
            >
              <Volume2 className="w-3.5 h-3.5 text-purple-400" />
              <span>{isAudioMuted ? 'Sound: Muted' : 'Romantic Audio: Active'}</span>
            </button>
          </motion.div>

          {/* Footer date */}
          <div className="mt-8 pt-6 border-t border-purple-500/15 flex items-center justify-between text-xs text-purple-300/70 px-2">
            <span className="flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-purple-400" />
              A Guided Experience for Seif
            </span>
            <span>{config.birthdayDate}</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
