import { GreetingConfig } from '../types';

/**
 * Generates a self-contained, standalone single .html file that runs out of the box
 * anywhere without any server or dependencies.
 */
export function generateStandaloneHtml(config: GreetingConfig): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Happy Birthday, ${escapeHtml(config.recipientName)}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Playfair+Display:ital,wght@0,400;0,600;1,400;1,600&family=Plus+Jakarta+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"><\/script>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background-color: #060710;
      color: #f1f5f9;
      font-family: 'Plus Jakarta Sans', sans-serif;
      min-height: 100vh;
      overflow-x: hidden;
      line-height: 1.6;
      -webkit-font-smoothing: antialiased;
    }
    .serif-luxury { font-family: 'Playfair Display', Georgia, serif; }
    .font-display { font-family: 'Outfit', sans-serif; }
    
    /* Cosmic backdrop canvas */
    #space-canvas {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      z-index: 0;
      pointer-events: none;
    }

    .app-container {
      position: relative;
      z-index: 10;
      max-width: 960px;
      margin: 0 auto;
      padding: 24px 20px 100px;
    }

    .glass-card {
      background: rgba(16, 20, 38, 0.75);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border: 1px solid rgba(168, 85, 247, 0.2);
      border-radius: 20px;
      padding: 32px 28px;
      transition: all 0.3s ease;
      box-shadow: 0 16px 40px -10px rgba(0,0,0,0.6);
    }
    .glass-card:hover {
      border-color: rgba(192, 132, 252, 0.4);
      box-shadow: 0 20px 50px -10px rgba(147, 51, 234, 0.2);
    }

    .btn-glow {
      background: linear-gradient(135deg, #9333ea, #7c3aed);
      color: white;
      padding: 14px 28px;
      border-radius: 9999px;
      border: none;
      font-weight: 600;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      font-size: 15px;
      letter-spacing: 0.02em;
      transition: all 0.25s ease;
      box-shadow: 0 8px 24px rgba(147, 51, 234, 0.4);
    }
    .btn-glow:hover {
      transform: translateY(-2px);
      box-shadow: 0 12px 30px rgba(147, 51, 234, 0.6);
    }

    .btn-secondary {
      background: rgba(255,255,255,0.06);
      color: #cbd5e1;
      padding: 12px 24px;
      border-radius: 9999px;
      border: 1px solid rgba(168, 85, 247, 0.2);
      font-weight: 500;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      font-size: 14px;
      transition: all 0.2s;
    }
    .btn-secondary:hover {
      background: rgba(168, 85, 247, 0.15);
      border-color: rgba(192, 132, 252, 0.4);
      color: white;
    }

    /* Candle flame animation */
    @keyframes flameDance {
      0%, 100% { transform: scale(1) rotate(-1deg); filter: drop-shadow(0 0 12px #c084fc); }
      50% { transform: scale(1.08) rotate(1.5deg); filter: drop-shadow(0 0 20px #fbbf24); }
    }
    .flame-active {
      animation: flameDance 1.6s infinite ease-in-out;
      transform-origin: bottom center;
    }

    .section {
      margin-bottom: 72px;
      display: none;
    }
    .section.active {
      display: block;
      animation: fadeIn 0.8s ease forwards;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(16px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .polaroid-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 20px;
      margin-top: 24px;
    }
    .polaroid-card {
      background: rgba(15, 18, 36, 0.85);
      border: 1px solid rgba(168, 85, 247, 0.2);
      border-radius: 16px;
      overflow: hidden;
      padding: 14px;
      cursor: pointer;
      transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .polaroid-card:hover {
      transform: translateY(-6px) scale(1.02);
      border-color: rgba(192, 132, 252, 0.5);
      box-shadow: 0 12px 30px rgba(147, 51, 234, 0.2);
    }
    .polaroid-card img {
      width: 100%;
      height: 180px;
      object-fit: cover;
      border-radius: 10px;
    }

    .audio-pill {
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 99;
      background: rgba(20, 24, 44, 0.85);
      border: 1px solid rgba(168, 85, 247, 0.3);
      backdrop-filter: blur(12px);
      padding: 10px 18px;
      border-radius: 9999px;
      display: flex;
      align-items: center;
      gap: 10px;
      cursor: pointer;
      font-size: 13px;
      color: #e2e8f0;
      box-shadow: 0 10px 30px rgba(0,0,0,0.5);
    }

    .chapter-nav {
      display: flex;
      gap: 8px;
      overflow-x: auto;
      padding: 8px;
      background: rgba(15, 18, 36, 0.85);
      backdrop-filter: blur(16px);
      border: 1px solid rgba(168, 85, 247, 0.2);
      border-radius: 9999px;
      margin: 0 auto 36px;
      width: fit-content;
      max-width: 100%;
    }
    .chapter-btn {
      background: transparent;
      border: none;
      color: #94a3b8;
      padding: 8px 18px;
      border-radius: 9999px;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      white-space: nowrap;
      transition: all 0.2s;
    }
    .chapter-btn.active {
      background: rgba(147, 51, 234, 0.25);
      color: #e9d5ff;
      border: 1px solid rgba(168, 85, 247, 0.5);
    }
  </style>
</head>
<body>
  <canvas id="space-canvas"></canvas>

  <div class="audio-pill" id="audio-toggle" onclick="toggleAudio()">
    <span id="audio-icon">&#9835;</span>
    <span id="audio-status">Sound: Romantic Melody On</span>
  </div>

  <div class="app-container">
    <!-- Chapter Navigation -->
    <div class="chapter-nav">
      <button class="chapter-btn active" onclick="switchChapter('gateway')">&#10024; Gateway</button>
      <button class="chapter-btn" onclick="switchChapter('memories')">&#128248; Moments</button>
      <button class="chapter-btn" onclick="switchChapter('reasons')">&#128142; Why You're Rare</button>
      <button class="chapter-btn" onclick="switchChapter('cake')">&#127874; Make a Wish</button>
      <button class="chapter-btn" onclick="switchChapter('letter')">&#128220; The Letter</button>
      <button class="chapter-btn" onclick="switchChapter('coupons')">&#127873; The Vault</button>
    </div>

    <!-- Chapter 1: Gateway -->
    <div id="sec-gateway" class="section active">
      <div class="glass-card" style="text-align: center; padding: 60px 32px;">
        <div style="font-size: 12px; letter-spacing: 0.25em; text-transform: uppercase; color: #c084fc; margin-bottom: 12px; font-weight: 600;">
          A Celestial Moment For Someone Truly Special
        </div>
        <h1 class="serif-luxury" style="font-size: clamp(36px, 6vw, 64px); font-weight: 600; margin-bottom: 16px; line-height: 1.15; color: #fff;">
          Happy Birthday, <br><span style="color: #c084fc;">${escapeHtml(config.recipientName)}</span> 🤍
        </h1>
        <p style="font-size: 18px; color: #cbd5e1; max-width: 600px; margin: 0 auto 36px; line-height: 1.6;">
          ${escapeHtml(config.ageDisplay)} &bull; ${escapeHtml(config.nickname)}
        </p>
        <div style="display: flex; justify-content: center; gap: 16px; flex-wrap: wrap;">
          <button class="btn-glow" onclick="switchChapter('memories'); playFanfare();">
            Enter the Journey &rarr;
          </button>
        </div>
      </div>
    </div>

    <!-- Chapter 2: Memories -->
    <div id="sec-memories" class="section">
      <div style="text-align: center; margin-bottom: 24px;">
        <h2 class="serif-luxury" style="font-size: 36px; margin-bottom: 8px;">Constellation of Moments</h2>
        <p style="color: #cbd5e1;">Late night calls, funny moments, shared laughs, and every moment with you.</p>
      </div>

      <!-- Gothic Aesthetic Quote Banner -->
      <div class="glass-card" style="padding: 24px; margin-bottom: 24px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 20px; border-color: rgba(192, 132, 252, 0.3);">
        <div style="display: flex; align-items: center; gap: 16px;">
          <img src="/assets/gothic_purple_banner.jpg" alt="Purple Lily Banner" style="width: 68px; height: 68px; object-fit: cover; border-radius: 12px; border: 1px solid rgba(192, 132, 252, 0.4);">
          <div>
            <div style="font-size: 11px; text-transform: uppercase; color: #c084fc; letter-spacing: 0.15em; font-weight: 600;">The Moonlight Reflection</div>
            <p class="serif-luxury" style="font-size: 20px; font-style: italic; color: #f3e8ff; margin: 4px 0 0;">
              "If the words you spoke appeared on your skin, would you still be beautiful?"
            </p>
          </div>
        </div>
        <p style="font-size: 13px; color: #d8b4fe; max-width: 280px; margin: 0; line-height: 1.5;">
          With you, every word has been genuine, hilarious, and gentle. That is why you are so rare. 🤍
        </p>
      </div>

      <div class="polaroid-grid">
        ${config.memories.map(m => `
          <div class="polaroid-card">
            ${m.imageUrl ? `<img src="${m.imageUrl}" alt="${escapeHtml(m.title)}">` : ''}
            <div style="font-size: 11px; text-transform: uppercase; color: #c084fc; font-weight: 600; margin-top: 10px;">${escapeHtml(m.tag)}</div>
            <h3 style="font-size: 17px; margin: 4px 0 6px; font-weight: 600;">${escapeHtml(m.title)}</h3>
            <p style="font-size: 13px; color: #cbd5e1; line-height: 1.5;">${escapeHtml(m.note)}</p>
          </div>
        `).join('')}
      </div>
      <div style="text-align: center; margin-top: 36px;">
        <button class="btn-glow" onclick="switchChapter('reasons')">Continue: Why You're Rare &rarr;</button>
      </div>
    </div>

    <!-- Chapter 3: Reasons -->
    <div id="sec-reasons" class="section">
      <div style="text-align: center; margin-bottom: 28px;">
        <h2 class="serif-luxury" style="font-size: 36px; margin-bottom: 8px;">6 Reasons You're Incomparable</h2>
        <p style="color: #cbd5e1;">Out of billions of people, here is why loving you is the easiest thing in the world.</p>
      </div>
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 18px;">
        ${config.reasons.map(r => `
          <div class="glass-card" style="padding: 24px;">
            <div style="font-size: 12px; color: #c084fc; font-weight: 700; margin-bottom: 6px;">${escapeHtml(r.number)} &bull; ${escapeHtml(r.category)}</div>
            <h4 style="font-size: 18px; margin-bottom: 8px; font-weight: 600;">${escapeHtml(r.title)}</h4>
            <p style="font-size: 14px; color: #cbd5e1; line-height: 1.55;">${escapeHtml(r.detail)}</p>
          </div>
        `).join('')}
      </div>
      <div style="text-align: center; margin-top: 36px;">
        <button class="btn-glow" onclick="switchChapter('cake')">Proceed to The Candle & Wish &rarr;</button>
      </div>
    </div>

    <!-- Chapter 4: Cake & Wish Ceremony -->
    <div id="sec-cake" class="section">
      <div class="glass-card" style="text-align: center; max-width: 650px; margin: 0 auto; padding: 48px 24px;">
        <h2 class="serif-luxury" style="font-size: 36px; margin-bottom: 8px;">The Birthday Candle</h2>
        <p style="color: #cbd5e1; margin-bottom: 36px;">Close your eyes, hold a secret wish in your heart, and extinguish the flame.</p>

        <!-- Dynamic Candle Container -->
        <div style="position: relative; width: 140px; height: 180px; margin: 0 auto 32px; display: flex; flex-direction: column; align-items: center; justify-content: flex-end;">
          <div id="candle-flame" class="flame-active" style="width: 24px; height: 38px; background: radial-gradient(circle, #fff 15%, #fef08a 35%, #f59e0b 70%, transparent 95%); border-radius: 50% 50% 35% 35%; margin-bottom: 4px;"></div>
          <div style="width: 4px; height: 12px; background: #475569;"></div>
          <div style="width: 32px; height: 90px; background: linear-gradient(to right, #9333ea, #c084fc, #7c3aed); border-radius: 6px 6px 0 0; box-shadow: 0 4px 15px rgba(147,51,234,0.4);"></div>
          <div style="width: 130px; height: 26px; background: linear-gradient(to bottom, #2e1065, #1e1b4b); border-radius: 12px; border: 1px solid rgba(168,85,247,0.3);"></div>
        </div>

        <div id="blow-action-container">
          <button id="blow-btn" class="btn-glow" onclick="extinguishCandle()">
            &#127788; Tap to Blow Out Candle
          </button>
        </div>

        <div id="wish-success-container" style="display: none; animation: fadeIn 0.6s ease;">
          <div style="font-size: 26px; margin-bottom: 8px; color: #e9d5ff;">&#10024; Your Wish Is Set Into The Stars! &#10024;</div>
          <p style="color: #c084fc; font-weight: 500; margin-bottom: 24px;">${escapeHtml(config.wishingStarDefault)}</p>
          <button class="btn-glow" onclick="switchChapter('letter')">Read Your Birthday Letter &rarr;</button>
        </div>
      </div>
    </div>

    <!-- Chapter 5: The Letter -->
    <div id="sec-letter" class="section">
      <div class="glass-card" style="max-width: 740px; margin: 0 auto; padding: 48px 36px; border: 1px solid rgba(168,85,247,0.3);">
        <div style="font-size: 13px; text-transform: uppercase; letter-spacing: 0.15em; color: #c084fc; margin-bottom: 20px; font-weight: 600;">
          A Private Letter for ${escapeHtml(config.recipientName)}
        </div>
        <h3 class="serif-luxury" style="font-size: 28px; margin-bottom: 24px; color: #fff;">${escapeHtml(config.letter.salutation)}</h3>
        ${config.letter.paragraphs.map(p => `
          <p style="font-size: 16px; color: #e2e8f0; line-height: 1.8; margin-bottom: 20px; font-family: 'Plus Jakarta Sans', sans-serif;">${escapeHtml(p)}</p>
        `).join('')}
        <div style="margin-top: 36px; border-top: 1px solid rgba(255,255,255,0.08); padding-top: 24px;">
          <p style="font-size: 15px; color: #94a3b8; font-style: italic;">${escapeHtml(config.letter.closing)}</p>
          <p class="serif-luxury" style="font-size: 22px; color: #c084fc; font-weight: 600; margin-top: 4px;">${escapeHtml(config.senderName)}</p>
          ${config.letter.postScript ? `
            <p style="font-size: 13px; color: #cbd5e1; margin-top: 16px; border-left: 2px solid #a855f7; padding-left: 12px; font-style: italic;">${escapeHtml(config.letter.postScript)}</p>
          ` : ''}
        </div>
      </div>
      <div style="text-align: center; margin-top: 36px;">
        <button class="btn-glow" onclick="switchChapter('coupons')">Open Your Virtual Vault &rarr;</button>
      </div>
    </div>

    <!-- Chapter 6: The Vault (Coupons) -->
    <div id="sec-coupons" class="section">
      <div style="text-align: center; margin-bottom: 28px;">
        <h2 class="serif-luxury" style="font-size: 36px; margin-bottom: 8px;">The Birthday Vault</h2>
        <p style="color: #cbd5e1;">Special VIP passes and promises redeemable anytime you choose.</p>
      </div>
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 18px;">
        ${config.coupons.map(c => `
          <div class="glass-card" style="padding: 24px; position: relative; border-left: 3px solid #a855f7;">
            <div style="font-size: 11px; text-transform: uppercase; color: #c084fc; font-weight: 700; margin-bottom: 4px;">${escapeHtml(c.tag)}</div>
            <h4 style="font-size: 18px; margin-bottom: 8px; font-weight: 600;">${escapeHtml(c.title)}</h4>
            <p style="font-size: 13px; color: #cbd5e1; line-height: 1.5; margin-bottom: 16px;">${escapeHtml(c.desc)}</p>
            <button class="btn-secondary" onclick="redeemCoupon(this)" style="font-size: 12px; padding: 6px 14px;">
              &#10003; Redeem Voucher
            </button>
          </div>
        `).join('')}
      </div>

      <div class="glass-card" style="margin-top: 40px; text-align: center; padding: 32px;">
        <div style="font-size: 12px; color: #94a3b8; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.1em;">Secret Encrypted Thought</div>
        <p class="serif-luxury" style="font-size: 20px; color: #e9d5ff; font-style: italic;">"${escapeHtml(config.secretCodeMessage)}"</p>
      </div>
    </div>
  </div>

  <script>
    // Embedded Audio Synth Engine
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    let audioContext = null;
    let isAudioMuted = false;
    let ambientTimer = null;

    function initAudio() {
      if (!audioContext && AudioCtx) {
        audioContext = new AudioCtx();
      }
      if (audioContext && audioContext.state === 'suspended') {
        audioContext.resume();
      }
    }

    function toggleAudio() {
      initAudio();
      isAudioMuted = !isAudioMuted;
      document.getElementById('audio-status').innerText = isAudioMuted ? 'Sound: Muted' : 'Sound: Romantic Melody On';
      document.getElementById('audio-icon').innerHTML = isAudioMuted ? '&#128263;' : '&#9835;';
      if (!isAudioMuted) {
        startAmbientSound();
      } else {
        clearInterval(ambientTimer);
      }
    }

    function playTone(freq, dur = 1.4, vol = 0.05) {
      if (isAudioMuted || !audioContext) return;
      try {
        const now = audioContext.currentTime;
        const osc = audioContext.createOscillator();
        const osc2 = audioContext.createOscillator();
        const gain = audioContext.createGain();
        osc.type = 'sine';
        osc2.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now);
        osc2.frequency.setValueAtTime(freq * 0.5, now);
        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(vol, now + 0.08);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);
        osc.connect(gain);
        osc2.connect(gain);
        gain.connect(audioContext.destination);
        osc.start(now);
        osc2.start(now);
        osc.stop(now + dur);
        osc2.stop(now + dur);
      } catch (e) {}
    }

    function startAmbientSound() {
      initAudio();
      // Romantic piano-like progression in D / Bm
      const melodyPhrases = [
        [293.66, 369.99, 440.00, 587.33],
        [246.94, 293.66, 369.99, 440.00],
        [220.00, 277.18, 329.63, 440.00],
        [196.00, 246.94, 293.66, 392.00]
      ];
      let phraseIdx = 0;
      if (ambientTimer) clearInterval(ambientTimer);
      const playNextPhrase = () => {
        if (isAudioMuted) return;
        const phrase = melodyPhrases[phraseIdx % melodyPhrases.length];
        phraseIdx++;
        phrase.forEach((freq, i) => {
          setTimeout(() => playTone(freq, 2.5, 0.04), i * 380);
        });
      };
      playNextPhrase();
      ambientTimer = setInterval(playNextPhrase, 3600);
    }

    function playFanfare() {
      initAudio();
      [293.66, 369.99, 440.00, 587.33, 739.99].forEach((f, idx) => {
        setTimeout(() => playTone(f, 1.2, 0.08), idx * 200);
      });
    }

    // Chapters Navigation
    function switchChapter(chapterId) {
      initAudio();
      playTone(587.33, 0.4, 0.04);
      document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
      document.querySelectorAll('.chapter-btn').forEach(b => b.classList.remove('active'));
      
      const targetSec = document.getElementById('sec-' + chapterId);
      if (targetSec) targetSec.classList.add('active');

      const btnMap = {
        'gateway': 0, 'memories': 1, 'reasons': 2, 'cake': 3, 'letter': 4, 'coupons': 5
      };
      const btns = document.querySelectorAll('.chapter-btn');
      if (btns[btnMap[chapterId]]) btns[btnMap[chapterId]].classList.add('active');

      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function extinguishCandle() {
      initAudio();
      const flame = document.getElementById('candle-flame');
      flame.style.display = 'none';
      
      document.getElementById('blow-action-container').style.display = 'none';
      document.getElementById('wish-success-container').style.display = 'block';

      playFanfare();
      if (window.confetti) {
        window.confetti({
          particleCount: 120,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#a855f7', '#c084fc', '#e9d5ff', '#fbbf24', '#ffffff']
        });
      }
    }

    function redeemCoupon(btn) {
      initAudio();
      playTone(880, 0.3, 0.06);
      btn.innerText = '&#10003; Redeemed!';
      btn.style.background = 'rgba(168, 85, 247, 0.25)';
      btn.style.borderColor = 'rgba(192, 132, 252, 0.6)';
      btn.style.color = '#e9d5ff';
      btn.disabled = true;
    }

    // Purple & Violet Starfield Canvas Background
    const canvas = document.getElementById('space-canvas');
    const ctx = canvas.getContext('2d');
    let stars = [];

    function resizeCanvas() {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      initStars();
    }
    window.addEventListener('resize', resizeCanvas);

    function initStars() {
      stars = [];
      const numStars = Math.floor((canvas.width * canvas.height) / 8000);
      for (let i = 0; i < numStars; i++) {
        stars.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          radius: Math.random() * 1.5,
          alpha: Math.random() * 0.8 + 0.2,
          speed: Math.random() * 0.3 + 0.1
        });
      }
    }

    function animateStars() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#ffffff';
      stars.forEach(s => {
        ctx.globalAlpha = s.alpha;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.radius, 0, Math.PI * 2);
        ctx.fill();
        s.y -= s.speed;
        if (s.y < 0) s.y = canvas.height;
      });
      requestAnimationFrame(animateStars);
    }

    resizeCanvas();
    animateStars();

    // Auto-start ambient audio on first click
    document.body.addEventListener('click', () => {
      if (!ambientTimer && !isAudioMuted) {
        startAmbientSound();
      }
    }, { once: true });
  </script>
</body>
</html>`;
}

function escapeHtml(str: string): string {
  return (str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
