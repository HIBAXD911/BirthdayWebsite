import { useState } from 'react';
import { motion } from 'motion/react';
import { Heart, ArrowRight, Feather } from 'lucide-react';
import { GreetingConfig } from '../types';
import { soundEngine } from '../utils/audio';

interface HeartfeltLetterProps {
  config: GreetingConfig;
  onNext: () => void;
}

export default function HeartfeltLetter({ config, onNext }: HeartfeltLetterProps) {
  return (
    <div className="max-w-3xl mx-auto px-4 py-10 relative z-10">
      {/* Section Header */}
      <div className="text-center max-w-xl mx-auto mb-10">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-purple-500/15 border border-purple-500/30 text-purple-300 text-xs font-semibold uppercase tracking-widest mb-3"
        >
          <Feather className="w-3.5 h-3.5 text-purple-400" />
          <span>Chapter 04 &bull; A Private Letter for {config.recipientName}</span>
        </motion.div>
        <motion.h2
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl font-semibold text-white tracking-tight mb-3"
        >
          Words Kept Close to the Chest
        </motion.h2>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-slate-300 text-sm sm:text-base leading-relaxed"
        >
          Take a quiet breath. Some things are too meaningful to leave unsaid.
        </motion.p>
      </div>

      {/* Luxury Letter Parchment Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25, duration: 0.8 }}
        className="relative bg-[#0d1022]/90 border border-purple-500/30 rounded-3xl p-8 sm:p-14 shadow-2xl shadow-purple-950/50 backdrop-blur-2xl overflow-hidden"
      >
        {/* Subtle decorative watermark */}
        <div className="absolute top-6 right-6 opacity-5 pointer-events-none">
          <Heart className="w-56 h-56 text-purple-400 fill-purple-400" />
        </div>

        {/* Salutation */}
        <h3 className="font-serif-luxury text-2xl sm:text-3xl text-white font-semibold mb-8 tracking-tight leading-snug">
          {config.letter.salutation}
        </h3>

        {/* Letter Paragraphs */}
        <div className="space-y-6 text-slate-200 text-base sm:text-lg leading-relaxed font-sans-clean">
          {config.letter.paragraphs.map((paragraph, index) => (
            <motion.p
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + index * 0.1 }}
            >
              {paragraph}
            </motion.p>
          ))}
        </div>

        {/* Sign-off & Signature */}
        <div className="mt-12 pt-8 border-t border-purple-500/15 flex flex-col sm:flex-row sm:items-end justify-between gap-6">
          <div>
            <p className="text-purple-300/80 text-sm italic mb-1 font-serif-luxury">
              {config.letter.closing}
            </p>
            <p className="font-serif-luxury text-2xl sm:text-3xl text-purple-200 font-semibold">
              {config.senderName}
            </p>
          </div>

          {/* Wax stamp badge */}
          <div className="flex items-center gap-3 self-start sm:self-auto">
            <div className="w-12 h-12 rounded-full border border-purple-400/40 bg-purple-950/70 flex items-center justify-center shadow-inner text-purple-300">
              <Heart className="w-5 h-5 fill-purple-400/40" />
            </div>
            <div className="text-left">
              <span className="block text-[11px] uppercase tracking-widest text-slate-400 font-semibold">
                Sealed With Love 🤍
              </span>
              <span className="block text-xs text-purple-200 font-display">
                {config.birthdayDate}
              </span>
            </div>
          </div>
        </div>

        {/* Postscript if present */}
        {config.letter.postScript && (
          <div className="mt-8 pt-4 border-t border-purple-500/10">
            <p className="text-xs sm:text-sm text-purple-200/90 italic bg-purple-500/[0.04] border-l-2 border-purple-400/70 pl-4 py-2 rounded-r-lg">
              {config.letter.postScript}
            </p>
          </div>
        )}
      </motion.div>

      {/* Next Step CTA */}
      <div className="mt-12 text-center">
        <button
          onClick={() => {
            soundEngine.playTone(783.99, 0.4, 0.07);
            onNext();
          }}
          className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white font-medium text-sm tracking-wide shadow-lg shadow-purple-900/40 hover:shadow-purple-600/50 transition-all cursor-pointer"
        >
          <span>Open Your Starlight Vault & Passes</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
