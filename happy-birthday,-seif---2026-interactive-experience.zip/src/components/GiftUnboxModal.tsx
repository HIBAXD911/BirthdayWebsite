import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import {
  Gift,
  Sparkles,
  Award,
  Heart,
  Car,
  PhoneCall,
  RotateCcw,
  Check,
  Lock,
  Unlock,
  Moon,
  Music,
  Tv,
  Gamepad2,
  MessageCircle,
  Stars,
  Play,
  Pause,
  Key
} from 'lucide-react';
import { GreetingConfig, CouponItem } from '../types';
import { soundEngine } from '../utils/audio';

interface GiftUnboxModalProps {
  config: GreetingConfig;
  onRestart: () => void;
  onOpenCustomize: () => void;
}

interface StarlightWhisper {
  id: number;
  starName: string;
  title: string;
  whisper: string;
  tag: string;
}

const STARLIGHT_WHISPERS: StarlightWhisper[] = [
  {
    id: 1,
    starName: 'The 2 AM Rule',
    title: 'Never Too Late',
    whisper: 'No matter how late it is or how exhausted I am, if you need to talk, vent, or just stay on call in comfortable silence, I will always stay awake for you.',
    tag: 'Late Night'
  },
  {
    id: 2,
    starName: 'The Daily Debrief',
    title: 'Every Tiny Detail',
    whisper: 'You never have to wonder if you are talking too much. Hearing you ramble about every tiny detail of your day, sharing funny moments, and telling random stories is genuinely the highlight of my day.',
    tag: 'Funny Moments'
  },
  {
    id: 3,
    starName: 'The Gaming Duo',
    title: 'Unstoppable Team',
    whisper: 'A lifetime promise of hours spent playing together, celebrating every clutch play, laughing off our silly fails, and always being your favorite teammate.',
    tag: 'Gaming Nights'
  },
  {
    id: 4,
    starName: 'When You Are Quiet',
    title: 'I Notice Everything',
    whisper: 'You never have to pretend everything is fine. I notice when you get quiet or when something is wrong, and you never have to carry anything alone when I am here.',
    tag: 'Safe Sanctuary'
  },
  {
    id: 5,
    starName: 'The Laughter Cure',
    title: 'Laughing Till It Hurts',
    whisper: 'Whenever you have had a rough day, I promise to send stupid jokes, stay up late, and do whatever it takes until we are laughing so hard we cannot breathe.',
    tag: 'Pure Joy'
  },
  {
    id: 6,
    starName: 'Movie Night Watch Parties',
    title: 'Synchronized Moments',
    whisper: 'Even across screens, counting \'3, 2, 1\' and watching movies with you feels warmer and cozier than being in any movie theater.',
    tag: 'Watch Together'
  },
  {
    id: 7,
    starName: 'Falling Deeper',
    title: 'More With Each Passing Day',
    whisper: 'Somewhere between the late-night calls, the shared jokes, and the random conversations, I found myself falling in love with you more and more with each passing day.',
    tag: 'Growing Love'
  },
  {
    id: 8,
    starName: 'My Favorite Idiot',
    title: 'Really Glad I Found You',
    whisper: 'In a universe of billions of people, having you in my life is something I will never take for granted. Happy birthday, idiot. 🤍',
    tag: 'Forever You'
  }
];

const LOVE_AFFIRMATIONS = [
  'Because your voice turns my whole day around.',
  'Because you stay up late just to talk to me.',
  'Because we laugh until our stomachs hurt.',
  'Because you listen to every tiny detail of my day.',
  'Because you notice when something is wrong before I speak.',
  'Because playing games with you makes time fly.',
  'Because you are genuinely my favorite person.',
  'Because finding you felt like finally coming home. 🤍',
  'Because I fall for you more with each passing day.'
];

export default function GiftUnboxModal({
  config,
  onRestart,
  onOpenCustomize,
}: GiftUnboxModalProps) {
  const [isUnboxed, setIsUnboxed] = useState(false);
  const [coupons, setCoupons] = useState<CouponItem[]>(config.coupons);
  const [showSecret, setShowSecret] = useState(false);
  const [activeWhisper, setActiveWhisper] = useState<StarlightWhisper | null>(null);
  const [revealedWhispers, setRevealedWhispers] = useState<number[]>([1]);
  const [isPlayingLullaby, setIsPlayingLullaby] = useState(false);
  const [loveClicks, setLoveClicks] = useState(0);

  const handleUnbox = () => {
    soundEngine.playUnwrapSound();
    setIsUnboxed(true);

    setTimeout(() => {
      soundEngine.playCelebrationFanfare();
      try {
        confetti({
          particleCount: 100,
          spread: 85,
          origin: { y: 0.5 },
          colors: ['#a855f7', '#c084fc', '#e9d5ff', '#fbbf24', '#f472b6'],
        });
      } catch {
        // Safe ignore
      }
    }, 400);
  };

  const handleRedeem = (id: string) => {
    soundEngine.playChime(880);
    setCoupons((prev) =>
      prev.map((c) => (c.id === id ? { ...c, redeemed: true } : c))
    );
  };

  const handleOpenWhisper = (whisper: StarlightWhisper) => {
    soundEngine.playChime(783.99);
    setActiveWhisper(whisper);
    if (!revealedWhispers.includes(whisper.id)) {
      setRevealedWhispers((prev) => [...prev, whisper.id]);
    }
  };

  const handleToggleLullaby = () => {
    if (isPlayingLullaby) {
      setIsPlayingLullaby(false);
    } else {
      setIsPlayingLullaby(true);
      soundEngine.playLoveLullaby();
      setTimeout(() => setIsPlayingLullaby(false), 4200);
    }
  };

  const handleHeartClick = () => {
    soundEngine.playChime(987.77);
    setLoveClicks((prev) => prev + 1);
  };

  const getCouponIcon = (iconName: string) => {
    switch (iconName.toLowerCase()) {
      case 'moon':
        return <Moon className="w-5 h-5 text-purple-400" />;
      case 'phonecall':
        return <PhoneCall className="w-5 h-5 text-violet-400" />;
      case 'gamepad2':
        return <Gamepad2 className="w-5 h-5 text-fuchsia-400" />;
      case 'tv':
        return <Tv className="w-5 h-5 text-indigo-400" />;
      case 'hearthandshake':
        return <Heart className="w-5 h-5 text-rose-400" />;
      case 'car':
        return <Car className="w-5 h-5 text-amber-400" />;
      case 'key':
        return <Key className="w-5 h-5 text-yellow-400" />;
      case 'award':
        return <Award className="w-5 h-5 text-purple-400" />;
      default:
        return <Sparkles className="w-5 h-5 text-purple-400" />;
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-10 relative z-10">
      {/* Section Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-purple-500/15 border border-purple-500/30 text-purple-300 text-xs font-semibold uppercase tracking-widest mb-3"
        >
          <Gift className="w-3.5 h-3.5 text-purple-400" />
          <span>Chapter 05 &bull; The Starlight Vault for {config.recipientName}</span>
        </motion.div>
        <motion.h2
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl font-semibold text-white tracking-tight mb-3"
        >
          Special Passes & Secret Whispers
        </motion.h2>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-slate-300 text-sm sm:text-base leading-relaxed font-sans-clean"
        >
          {isUnboxed
            ? `Your personalized birthday vault is unlocked! These passes, starlight promises, and secret thoughts are yours forever.`
            : `Tap the royal purple gift box below to untie the golden silk ribbon and unveil your surprises.`}
        </motion.p>
      </div>

      {!isUnboxed ? (
        /* The Mystery Purple Gift Box */
        <div className="flex flex-col items-center justify-center my-10">
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleUnbox}
            className="cursor-pointer relative w-60 h-60 sm:w-72 sm:h-72 flex flex-col items-center justify-center group"
          >
            {/* Glowing violet/purple aura */}
            <div className="absolute inset-0 bg-gradient-to-tr from-purple-600/40 via-violet-500/30 to-fuchsia-500/30 rounded-3xl blur-3xl animate-pulse" />

            {/* Gift Box Container */}
            <div className="relative w-48 h-48 sm:w-56 sm:h-56 rounded-3xl bg-gradient-to-br from-purple-900 via-purple-950 to-indigo-950 border-2 border-purple-400/40 shadow-2xl flex items-center justify-center overflow-hidden transition-all duration-300 group-hover:border-purple-300/70">
              {/* Vertical Golden Silk Ribbon */}
              <div className="absolute inset-y-0 w-8 bg-gradient-to-r from-amber-300 via-amber-200 to-amber-400 shadow-lg" />
              {/* Horizontal Golden Silk Ribbon */}
              <div className="absolute inset-x-0 h-8 bg-gradient-to-b from-amber-300 via-amber-200 to-amber-400 shadow-lg" />

              {/* Velvet Bow on Top */}
              <div className="absolute -top-4 w-16 h-10 flex justify-center items-center z-20">
                <div className="w-8 h-8 rounded-full border-2 border-amber-200 bg-amber-400 shadow-xl flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-amber-900" />
                </div>
              </div>

              {/* Floating Sparkle Center */}
              <Sparkles className="w-9 h-9 text-amber-200 z-10 animate-spin-slow drop-shadow" />
            </div>

            <span className="text-xs font-semibold text-purple-200 uppercase tracking-widest mt-6 bg-purple-500/20 px-5 py-2 rounded-full border border-purple-400/30 shadow-lg group-hover:bg-purple-500/30 transition-all">
              Tap to Untie Silk Ribbon & Unlock
            </span>
          </motion.div>
        </div>
      ) : (
        /* UNBOXED EXPANDED VAULT */
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="space-y-12"
        >
          {/* 1. THE STARLIGHT TIME CAPSULE: 8 Whispers & Promises */}
          <div className="relative rounded-3xl p-6 sm:p-8 bg-gradient-to-br from-purple-950/40 via-[#0d1020]/90 to-[#120f26]/90 border border-purple-500/30 shadow-2xl backdrop-blur-xl">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-4 border-b border-purple-500/20">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-semibold uppercase tracking-wider mb-2">
                  <Stars className="w-3.5 h-3.5 text-purple-400" />
                  <span>The Starlight Time Capsule</span>
                </div>
                <h3 className="font-serif-luxury text-2xl sm:text-3xl text-white font-semibold">
                  8 Late-Night Whispers & Promises for Seif
                </h3>
                <p className="text-xs sm:text-sm text-slate-400 mt-1">
                  Tap any of the 8 glowing stars to unroll an unsaid feeling, inside memory, or late-night promise.
                </p>
              </div>

              {/* Romantic Music Box Mini Player */}
              <div className="bg-purple-900/30 border border-purple-400/30 rounded-2xl p-3 flex items-center gap-3">
                <button
                  onClick={handleToggleLullaby}
                  className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white flex items-center justify-center shadow-md transition-all cursor-pointer"
                  title="Play Romantic Music Box Melody"
                >
                  {isPlayingLullaby ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                </button>
                <div className="text-left">
                  <span className="block text-[11px] text-purple-300 font-semibold uppercase tracking-wider">
                    {isPlayingLullaby ? 'Playing Music Box...' : 'Play Romantic Music Box'}
                  </span>
                  <span className="block text-xs text-slate-400">
                    A special gentle melody for you
                  </span>
                </div>
              </div>
            </div>

            {/* Interactive Stars Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mb-6">
              {STARLIGHT_WHISPERS.map((item) => {
                const isOpened = revealedWhispers.includes(item.id);
                const isSelected = activeWhisper?.id === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleOpenWhisper(item)}
                    className={`p-4 rounded-2xl border text-left transition-all duration-300 cursor-pointer relative overflow-hidden flex flex-col justify-between ${
                      isSelected
                        ? 'bg-purple-900/50 border-purple-400 shadow-lg shadow-purple-900/40 ring-2 ring-purple-400/40'
                        : isOpened
                        ? 'bg-purple-950/30 border-purple-500/30 hover:border-purple-400/60'
                        : 'bg-white/5 border-white/10 hover:border-purple-400/40'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-medium">
                        Star #{item.id}
                      </span>
                      <Stars
                        className={`w-4 h-4 transition-transform ${
                          isOpened ? 'text-amber-300 scale-110' : 'text-slate-500'
                        }`}
                      />
                    </div>
                    <p className="text-xs font-semibold text-white truncate">
                      {item.starName}
                    </p>
                    <span className="text-[11px] text-slate-400 mt-1 truncate">
                      {item.tag}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Active Whisper Unfolded Content */}
            <AnimatePresence mode="wait">
              {activeWhisper && (
                <motion.div
                  key={activeWhisper.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="p-6 rounded-2xl bg-[#090b16]/95 border border-purple-400/40 shadow-inner"
                >
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-xs font-semibold uppercase tracking-wider text-purple-300">
                      &bull; {activeWhisper.starName} &bull;
                    </span>
                    <span className="text-[11px] text-amber-300 bg-amber-500/15 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                      {activeWhisper.tag}
                    </span>
                  </div>
                  <h4 className="font-serif-luxury text-xl sm:text-2xl text-white font-semibold mb-2">
                    {activeWhisper.title}
                  </h4>
                  <p className="text-slate-200 text-sm sm:text-base leading-relaxed font-sans-clean">
                    "{activeWhisper.whisper}"
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* 2. INTERACTIVE 'WHY I FALL FOR YOU' HEART COUNTER */}
          <div className="bg-gradient-to-r from-purple-950/40 via-[#100e24]/80 to-purple-950/40 border border-purple-500/30 rounded-3xl p-6 sm:p-8 backdrop-blur-xl text-center">
            <motion.div
              whileHover={{ scale: 1.15 }}
              whileTap={{ scale: 0.9 }}
              onClick={handleHeartClick}
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-tr from-purple-600 via-violet-500 to-fuchsia-600 shadow-xl shadow-purple-900/50 mx-auto flex items-center justify-center cursor-pointer mb-3 relative group"
            >
              <Heart className="w-8 h-8 sm:w-10 sm:h-10 text-white fill-white group-hover:scale-110 transition-transform" />
              <div className="absolute -inset-1 rounded-full border border-purple-400/40 animate-ping opacity-40 pointer-events-none" />
            </motion.div>

            <h4 className="font-serif-luxury text-2xl sm:text-3xl text-white font-semibold mb-1">
              Why I Fall For You More With Each Passing Day
            </h4>
            <p className="text-xs sm:text-sm text-purple-300 mb-3">
              Tap the heart to generate another tender reason ({loveClicks} tapped so far)
            </p>

            <div className="min-h-12 flex items-center justify-center px-4">
              <motion.p
                key={loveClicks}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="font-serif-luxury text-base sm:text-lg text-slate-200 italic max-w-xl"
              >
                "{LOVE_AFFIRMATIONS[loveClicks % LOVE_AFFIRMATIONS.length]}"
              </motion.p>
            </div>
          </div>

          {/* 3. REDEEMABLE VIP PASSES GRID */}
          <div>
            <div className="mb-4">
              <h3 className="font-serif-luxury text-2xl text-white font-semibold">
                Personalized Passes & Vouchers
              </h3>
              <p className="text-xs text-slate-400">
                Claimable anytime with zero expiration date:
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {coupons.map((coupon, idx) => (
                <motion.div
                  key={coupon.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.08 }}
                  className={`relative rounded-2xl p-5 border transition-all duration-300 flex flex-col justify-between ${
                    coupon.redeemed
                      ? 'bg-purple-950/20 border-purple-500/40 text-slate-300'
                      : 'bg-[#101326]/85 border-purple-500/20 hover:border-purple-400/50 hover:shadow-lg hover:shadow-purple-900/20'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span
                        className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full ${
                          coupon.redeemed
                            ? 'bg-purple-500/30 text-purple-200'
                            : 'bg-purple-500/15 text-purple-300'
                        }`}
                      >
                        {coupon.tag}
                      </span>
                      <div className="w-8 h-8 rounded-full bg-purple-900/40 border border-purple-500/20 flex items-center justify-center">
                        {getCouponIcon(coupon.icon)}
                      </div>
                    </div>

                    <h4 className="font-display font-semibold text-white text-base mb-1.5">
                      {coupon.title}
                    </h4>
                    <p className="text-xs text-slate-400 leading-relaxed font-sans-clean mb-4">
                      {coupon.desc}
                    </p>
                  </div>

                  <button
                    disabled={coupon.redeemed}
                    onClick={() => handleRedeem(coupon.id)}
                    className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      coupon.redeemed
                        ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                        : 'bg-purple-600/30 hover:bg-purple-600 hover:text-white text-purple-200 border border-purple-400/30'
                    }`}
                  >
                    {coupon.redeemed ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-purple-300" />
                        <span>Pass Claimed & Valid!</span>
                      </>
                    ) : (
                      <span>Claim Pass</span>
                    )}
                  </button>
                </motion.div>
              ))}
            </div>
          </div>

          {/* 4. THE ENCRYPTED SECRET VAULT NOTE */}
          <div className="bg-[#0e1022]/90 border border-purple-500/30 rounded-3xl p-6 sm:p-8 backdrop-blur-xl text-center max-w-xl mx-auto shadow-xl">
            <div className="w-12 h-12 rounded-full bg-purple-500/20 text-purple-300 mx-auto flex items-center justify-center mb-3">
              {showSecret ? (
                <Unlock className="w-6 h-6 text-purple-300" />
              ) : (
                <Lock className="w-6 h-6 text-purple-300" />
              )}
            </div>

            <h4 className="font-display font-semibold text-white text-lg mb-1">
              One Last Encrypted Thought for Seif
            </h4>
            <p className="text-xs text-slate-400 mb-4">
              A private note sealed inside the vault just for your eyes.
            </p>

            {showSecret ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-5 rounded-2xl bg-purple-950/40 border border-purple-400/40 mb-2"
              >
                <p className="font-serif-luxury text-xl sm:text-2xl text-purple-200 italic leading-relaxed">
                  "{config.secretCodeMessage}"
                </p>
              </motion.div>
            ) : (
              <button
                onClick={() => {
                  soundEngine.playChime(987.77);
                  setShowSecret(true);
                }}
                className="px-6 py-2.5 rounded-full bg-purple-600/40 hover:bg-purple-600/70 border border-purple-400/40 text-purple-200 text-xs font-semibold cursor-pointer transition-all shadow-md shadow-purple-900/30"
              >
                Decrypt Secret Vault Message
              </button>
            )}
          </div>

          {/* 5. EXPERIENCE ACTIONS: Restart & Personalize */}
          <div className="pt-6 flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => {
                soundEngine.playTone(523.25, 0.4, 0.05);
                onRestart();
              }}
              className="px-6 py-3 rounded-full bg-white/10 hover:bg-white/15 text-white text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer"
            >
              <RotateCcw className="w-4 h-4 text-slate-400" />
              <span>Experience Journey From Start</span>
            </button>

            <button
              onClick={onOpenCustomize}
              className="px-6 py-3 rounded-full bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white text-xs font-semibold flex items-center gap-2 shadow-lg shadow-purple-600/30 cursor-pointer transition-all"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Personalize / Export Standalone HTML</span>
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
}
