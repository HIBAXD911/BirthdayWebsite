import { useState } from 'react';
import { motion } from 'motion/react';
import {
  X,
  Sparkles,
  Download,
  Share2,
  Check,
  Heart,
  User,
  RotateCcw,
  FileCode,
  Copy
} from 'lucide-react';
import { GreetingConfig, RelationshipType } from '../types';
import { PARTNER_PRESET, CRUSH_PRESET, BEST_FRIEND_PRESET } from '../data/presets';
import { generateStandaloneHtml } from '../utils/exportHtml';
import { soundEngine } from '../utils/audio';

interface CustomizeModalProps {
  config: GreetingConfig;
  isOpen: boolean;
  onClose: () => void;
  onUpdateConfig: (newConfig: GreetingConfig) => void;
}

export default function CustomizeModal({
  config,
  isOpen,
  onClose,
  onUpdateConfig,
}: CustomizeModalProps) {
  const [activeTab, setActiveTab] = useState<'presets' | 'basics' | 'letter' | 'export'>('presets');
  const [recipient, setRecipient] = useState(config.recipientName);
  const [sender, setSender] = useState(config.senderName);
  const [nickname, setNickname] = useState(config.nickname);
  const [ageDisplay, setAgeDisplay] = useState(config.ageDisplay);
  const [birthdayDate, setBirthdayDate] = useState(config.birthdayDate);
  const [secretCode, setSecretCode] = useState(config.secretCodeMessage);
  const [paragraphs, setParagraphs] = useState<string[]>(config.letter.paragraphs);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedHtml, setCopiedHtml] = useState(false);

  if (!isOpen) return null;

  const handleApplyPreset = (preset: GreetingConfig) => {
    soundEngine.playChime(783.99);
    setRecipient(preset.recipientName);
    setSender(preset.senderName);
    setNickname(preset.nickname);
    setAgeDisplay(preset.ageDisplay);
    setBirthdayDate(preset.birthdayDate);
    setSecretCode(preset.secretCodeMessage);
    setParagraphs(preset.letter.paragraphs);
    onUpdateConfig({ ...preset });
  };

  const handleSaveBasics = (e: React.FormEvent) => {
    e.preventDefault();
    soundEngine.playTone(659.25, 0.4, 0.06);
    onUpdateConfig({
      ...config,
      recipientName: recipient,
      senderName: sender,
      nickname,
      ageDisplay,
      birthdayDate,
      secretCodeMessage: secretCode,
      letter: {
        ...config.letter,
        paragraphs,
      },
    });
    onClose();
  };

  const handleDownloadStandaloneHtml = () => {
    soundEngine.playChime(1046.5);
    const updatedConfig = {
      ...config,
      recipientName: recipient,
      senderName: sender,
      nickname,
      ageDisplay,
      birthdayDate,
      secretCodeMessage: secretCode,
      letter: {
        ...config.letter,
        paragraphs,
      },
    };

    const htmlContent = generateStandaloneHtml(updatedConfig);
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `happy-birthday-${recipient.toLowerCase().replace(/\s+/g, '-')}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleCopyShareLink = () => {
    soundEngine.playChime(880);
    const shareUrl = window.location.origin + window.location.pathname;
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    });
  };

  const handleCopyRawHtml = () => {
    soundEngine.playChime(880);
    const updatedConfig = {
      ...config,
      recipientName: recipient,
      senderName: sender,
      nickname,
      ageDisplay,
      birthdayDate,
      secretCodeMessage: secretCode,
      letter: {
        ...config.letter,
        paragraphs,
      },
    };
    const htmlContent = generateStandaloneHtml(updatedConfig);
    navigator.clipboard.writeText(htmlContent).then(() => {
      setCopiedHtml(true);
      setTimeout(() => setCopiedHtml(false), 2500);
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-[#0f1325] border border-white/15 rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative my-8"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-9 h-9 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/15 text-rose-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Customize & Export</span>
          </div>
          <h3 className="font-serif-luxury text-2xl sm:text-3xl text-white font-semibold">
            Make It Truly Theirs
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Personalize the names, tone of voice, or export as a 100% self-contained single HTML file.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-white/10 mb-6 gap-2 sm:gap-4 overflow-x-auto pb-1">
          <button
            onClick={() => setActiveTab('presets')}
            className={`pb-2.5 px-2 text-xs font-medium border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'presets'
                ? 'border-rose-400 text-rose-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Relationship Presets
          </button>
          <button
            onClick={() => setActiveTab('basics')}
            className={`pb-2.5 px-2 text-xs font-medium border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'basics'
                ? 'border-rose-400 text-rose-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Recipient Info
          </button>
          <button
            onClick={() => setActiveTab('letter')}
            className={`pb-2.5 px-2 text-xs font-medium border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'letter'
                ? 'border-rose-400 text-rose-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Heartfelt Letter
          </button>
          <button
            onClick={() => setActiveTab('export')}
            className={`pb-2.5 px-2 text-xs font-medium border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'export'
                ? 'border-amber-400 text-amber-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Standalone .HTML Export
          </button>
        </div>

        {/* Tab 1: Presets */}
        {activeTab === 'presets' && (
          <div className="space-y-4">
            <p className="text-xs text-slate-400 mb-2">
              Select who this is for to instantly adapt the tone, memories, and reasons:
            </p>

            {/* Boyfriend / Partner Preset */}
            <div
              onClick={() => handleApplyPreset(PARTNER_PRESET)}
              className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-start justify-between ${
                config.relationship === 'partner'
                  ? 'bg-rose-950/30 border-rose-500/50 shadow-md shadow-rose-900/20'
                  : 'bg-white/5 border-white/10 hover:border-white/20'
              }`}
            >
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-display font-semibold text-white text-base">
                    Significant Other / Boyfriend / Girlfriend
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-medium">
                    Romantic
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Deeply heartfelt, intimate, and romantic tone. Celebrates quiet glances, road trips, and eternal connection.
                </p>
              </div>
              {config.relationship === 'partner' && (
                <Check className="w-5 h-5 text-rose-400 shrink-0 ml-3" />
              )}
            </div>

            {/* Crush Preset */}
            <div
              onClick={() => handleApplyPreset(CRUSH_PRESET)}
              className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-start justify-between ${
                config.relationship === 'crush'
                  ? 'bg-purple-950/30 border-purple-500/50 shadow-md shadow-purple-900/20'
                  : 'bg-white/5 border-white/10 hover:border-white/20'
              }`}
            >
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-display font-semibold text-white text-base">
                    A Special Crush / Someone Admired
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-medium">
                    Enchanting
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Subtle, magnetic, captivating, and sweet. Compliments their effortless aura, wit, and charm without being overbearing.
                </p>
              </div>
              {config.relationship === 'crush' && (
                <Check className="w-5 h-5 text-purple-400 shrink-0 ml-3" />
              )}
            </div>

            {/* Best Friend Preset */}
            <div
              onClick={() => handleApplyPreset(BEST_FRIEND_PRESET)}
              className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-start justify-between ${
                config.relationship === 'best_friend'
                  ? 'bg-amber-950/30 border-amber-500/50 shadow-md shadow-amber-900/20'
                  : 'bg-white/5 border-white/10 hover:border-white/20'
              }`}
            >
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-display font-semibold text-white text-base">
                    Best Friend / Ride-or-Die
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-medium">
                    Iconic Chaos
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Fiercely loyal, hilarious, 2 AM debrief energy. Inside jokes, telepathic looks, and lifelong partnership.
                </p>
              </div>
              {config.relationship === 'best_friend' && (
                <Check className="w-5 h-5 text-amber-400 shrink-0 ml-3" />
              )}
            </div>
          </div>
        )}

        {/* Tab 2: Basics */}
        {activeTab === 'basics' && (
          <form onSubmit={handleSaveBasics} className="space-y-4 text-left">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Recipient Name
                </label>
                <input
                  type="text"
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-rose-400"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Sender Name / Sign-off
                </label>
                <input
                  type="text"
                  value={sender}
                  onChange={(e) => setSender(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-rose-400"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Affectionate Nickname
                </label>
                <input
                  type="text"
                  value={nickname}
                  onChange={(e) => setNickname(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-rose-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Age / Milestone Tagline
                </label>
                <input
                  type="text"
                  value={ageDisplay}
                  onChange={(e) => setAgeDisplay(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-rose-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Secret Encrypted Message (In Vault)
              </label>
              <input
                type="text"
                value={secretCode}
                onChange={(e) => setSecretCode(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-rose-400"
              />
            </div>

            <div className="pt-3 flex justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold cursor-pointer shadow-md shadow-rose-600/30"
              >
                Apply Changes
              </button>
            </div>
          </form>
        )}

        {/* Tab 3: Letter */}
        {activeTab === 'letter' && (
          <div className="space-y-4 text-left">
            <p className="text-xs text-slate-400">
              Customize each paragraph of the heartfelt birthday letter:
            </p>
            {paragraphs.map((p, idx) => (
              <div key={idx}>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Paragraph {idx + 1}
                </label>
                <textarea
                  rows={3}
                  value={p}
                  onChange={(e) => {
                    const updated = [...paragraphs];
                    updated[idx] = e.target.value;
                    setParagraphs(updated);
                  }}
                  className="w-full px-3.5 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-xs focus:outline-none focus:border-rose-400 resize-none font-sans-clean"
                />
              </div>
            ))}

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  onUpdateConfig({
                    ...config,
                    letter: {
                      ...config.letter,
                      paragraphs,
                    },
                  });
                  onClose();
                }}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold cursor-pointer shadow-md shadow-rose-600/30"
              >
                Save Letter
              </button>
            </div>
          </div>
        )}

        {/* Tab 4: Export Standalone HTML */}
        {activeTab === 'export' && (
          <div className="space-y-6 text-center py-2">
            <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-left">
              <div className="flex items-center gap-2 text-amber-300 font-semibold text-sm mb-1.5">
                <FileCode className="w-4 h-4" />
                <span>100% Self-Contained Single HTML File</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Need to deliver this directly via AirDrop, WhatsApp, or email? Click below to download a single self-contained <code className="bg-black/40 px-1 py-0.5 rounded text-amber-200">.html</code> file. It requires zero server, runs out of the box in any browser, and contains all animations, cosmic canvas, audio synthesizer, and custom greetings.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={handleDownloadStandaloneHtml}
                className="w-full sm:w-auto px-6 py-3.5 rounded-full bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-lg shadow-amber-600/25 transition-all cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Standalone .HTML File</span>
              </button>

              <button
                onClick={handleCopyRawHtml}
                className="w-full sm:w-auto px-5 py-3 rounded-full bg-white/10 hover:bg-white/15 text-white text-xs font-medium flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                {copiedHtml ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied HTML Code!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-300" />
                    <span>Copy HTML Code</span>
                  </>
                )}
              </button>
            </div>

            <div className="pt-4 border-t border-white/10 flex items-center justify-between">
              <span className="text-xs text-slate-400">Share instant live web link:</span>
              <button
                onClick={handleCopyShareLink}
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-slate-300 flex items-center gap-1.5 cursor-pointer"
              >
                {copiedLink ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Link Copied!</span>
                  </>
                ) : (
                  <>
                    <Share2 className="w-3.5 h-3.5" />
                    <span>Copy Web App URL</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}
