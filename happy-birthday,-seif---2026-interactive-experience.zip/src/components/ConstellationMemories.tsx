import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  Camera,
  X,
  Plus,
  ArrowRight,
  Heart,
  Calendar,
  Image as ImageIcon,
  Quote,
  Check
} from 'lucide-react';
import { MemoryItem } from '../types';
import { soundEngine } from '../utils/audio';

interface ConstellationMemoriesProps {
  memories: MemoryItem[];
  recipientName: string;
  onNext: () => void;
  onAddMemory: (mem: MemoryItem) => void;
}

export const CUTE_DESIGNS = [
  {
    id: 'lilies',
    name: 'Glowing Purple Lilies',
    url: '/assets/glowing_purple_lilies.jpg',
    desc: 'Luminous fantasy garden with glowing lilies'
  },
  {
    id: 'cathedral',
    name: 'Moonlit Castle & Roses',
    url: '/assets/purple_roses_cathedral.jpg',
    desc: 'Cathedral towers and blooming purple roses'
  },
  {
    id: 'wildflowers',
    name: 'Purple Moon Wildflowers',
    url: '/assets/purple_moon_wildflowers.jpg',
    desc: 'Giant purple full moon over night flowers'
  },
  {
    id: 'crescent',
    name: 'Crescent Moon & Star',
    url: '/assets/crescent_moon_star.jpg',
    desc: 'Velvet dark clouds and cradled shining star'
  },
  {
    id: 'banner',
    name: 'Gothic Purple Crest',
    url: '/assets/gothic_purple_banner.jpg',
    desc: 'Vintage gothic filigree and purple bloom'
  }
];

export default function ConstellationMemories({
  memories,
  recipientName,
  onNext,
  onAddMemory,
}: ConstellationMemoriesProps) {
  const [selectedMemory, setSelectedMemory] = useState<MemoryItem | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newSubtitle, setNewSubtitle] = useState('');
  const [newDate, setNewDate] = useState('');
  const [newTag, setNewTag] = useState('Funny Moments');
  const [newNote, setNewNote] = useState('');
  const [selectedCoverUrl, setSelectedCoverUrl] = useState(CUTE_DESIGNS[0].url);
  const [customImageUrl, setCustomImageUrl] = useState('');

  const handleCardClick = (mem: MemoryItem) => {
    soundEngine.playChime(659.25);
    setSelectedMemory(mem);
  };

  const handleSaveMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newNote.trim()) return;

    const newMem: MemoryItem = {
      id: `mem-${Date.now()}`,
      title: newTitle.trim(),
      subtitle: newSubtitle.trim() || 'A Treasured Moment',
      date: newDate.trim() || 'Just between us',
      tag: newTag.trim() || 'Funny Moments',
      note: newNote.trim(),
      imageUrl: customImageUrl.trim() || selectedCoverUrl,
      iconName: 'Sparkles',
    };

    onAddMemory(newMem);
    soundEngine.playTone(880, 0.5, 0.08);
    setIsAdding(false);
    setNewTitle('');
    setNewSubtitle('');
    setNewNote('');
    setCustomImageUrl('');
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 relative z-10">
      {/* Section Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-purple-500/15 border border-purple-500/30 text-purple-300 text-xs font-semibold uppercase tracking-widest mb-3"
        >
          <Camera className="w-3.5 h-3.5 text-purple-400" />
          <span>Chapter 01 &bull; Constellation of Moments</span>
        </motion.div>
        <motion.h2
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl font-semibold text-white tracking-tight mb-4"
        >
          Moments Suspended in Time
        </motion.h2>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-slate-300 text-base leading-relaxed"
        >
          Every late-night call, funny moment, shared joke, and quiet glance with {recipientName}{' '}
          is woven into something unforgettable. Click any card to unveil its story.
        </motion.p>
      </div>

      {/* Gothic Aesthetic Quote Banner (Directly inspired by Purple Banner design) */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25 }}
        className="mb-12 relative overflow-hidden rounded-3xl border border-purple-500/30 bg-[#0c0d1e]/90 backdrop-blur-xl shadow-2xl p-6 sm:p-8"
      >
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-16 -bottom-16 w-64 h-64 bg-violet-600/15 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-6 text-center md:text-left justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 shrink-0 rounded-2xl overflow-hidden border border-purple-400/40 shadow-lg shadow-purple-950/50">
              <img
                src="/assets/gothic_purple_banner.jpg"
                alt="Purple Lily Banner"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="flex items-center justify-center md:justify-start gap-1.5 text-xs text-purple-300 font-serif-luxury italic mb-1">
                <Quote className="w-3.5 h-3.5 text-purple-400" />
                <span>The Moonlight Reflection</span>
              </div>
              <p className="font-serif-luxury text-lg sm:text-2xl text-purple-100 font-medium italic leading-snug">
                "If the words you spoke appeared on your skin, would you still be beautiful?"
              </p>
            </div>
          </div>
          
          <div className="shrink-0 max-w-xs text-center md:text-right border-t md:border-t-0 md:border-l border-purple-500/20 pt-3 md:pt-0 md:pl-6">
            <p className="text-xs sm:text-sm text-purple-200/90 leading-relaxed font-display">
              With you, every word has been genuine, hilarious, and gentle. That is why you are so rare. 🤍
            </p>
          </div>
        </div>
      </motion.div>

      {/* Grid of Polaroid Memory Cards with Bespoke Designs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {memories.map((mem, index) => (
          <motion.div
            key={mem.id}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.06 + 0.1, duration: 0.5 }}
            whileHover={{ y: -6, scale: 1.02 }}
            onClick={() => handleCardClick(mem)}
            className="group bg-[#0f1224]/85 border border-purple-500/20 hover:border-purple-400/50 rounded-2xl p-4 backdrop-blur-xl shadow-lg hover:shadow-purple-900/30 cursor-pointer transition-all duration-300 flex flex-col justify-between"
          >
            <div>
              {/* Image Frame */}
              <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-slate-900 mb-3.5 border border-purple-500/20">
                {mem.imageUrl ? (
                  <img
                    src={mem.imageUrl}
                    alt={mem.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    loading="lazy"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-slate-800 text-slate-500">
                    <ImageIcon className="w-8 h-8" />
                  </div>
                )}
                <div className="absolute top-2.5 left-2.5 px-2.5 py-0.5 rounded-full bg-black/60 backdrop-blur-md border border-purple-400/30 text-[11px] font-medium text-purple-200">
                  {mem.tag}
                </div>
              </div>

              {/* Title & Subtitle */}
              <h3 className="font-display font-semibold text-white text-lg group-hover:text-purple-300 transition-colors line-clamp-1 mb-1">
                {mem.title}
              </h3>
              <p className="text-xs text-purple-300/80 line-clamp-1 mb-2">
                {mem.subtitle}
              </p>
              <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed font-sans-clean">
                {mem.note}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-purple-500/15 flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1 text-slate-400">
                <Calendar className="w-3 h-3 text-purple-400" />
                {mem.date || 'Special Moment'}
              </span>
              <span className="text-purple-400 group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5 font-medium">
                View &rarr;
              </span>
            </div>
          </motion.div>
        ))}

        {/* Add Memory Card */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: memories.length * 0.06 + 0.1 }}
          whileHover={{ y: -4 }}
          onClick={() => {
            soundEngine.playChime(523.25);
            setIsAdding(true);
          }}
          className="border-2 border-dashed border-purple-500/30 hover:border-purple-400/60 rounded-2xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-colors bg-purple-500/[0.03] hover:bg-purple-500/[0.08] min-h-[260px]"
        >
          <div className="w-12 h-12 rounded-full bg-purple-500/15 flex items-center justify-center text-purple-300 mb-3 group-hover:scale-110 transition-transform">
            <Plus className="w-6 h-6 text-purple-400" />
          </div>
          <h4 className="text-sm font-semibold text-white mb-1">Add Another Moment</h4>
          <p className="text-xs text-slate-400 max-w-[200px]">
            Add another late-night memory or funny inside moment with {recipientName}.
          </p>
        </motion.div>
      </div>

      {/* Continue Button */}
      <div className="mt-14 text-center">
        <button
          onClick={() => {
            soundEngine.playTone(523.25, 0.4, 0.05);
            onNext();
          }}
          className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white font-medium text-sm tracking-wide shadow-lg shadow-purple-900/40 hover:shadow-purple-600/50 transition-all cursor-pointer"
        >
          <span>Continue: Why You're Rare</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Memory Detail Modal */}
      <AnimatePresence>
        {selectedMemory && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-[#0f1225] border border-purple-500/30 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl relative"
            >
              <button
                onClick={() => setSelectedMemory(null)}
                className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-black/60 text-white/80 hover:text-white flex items-center justify-center backdrop-blur-md transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              {selectedMemory.imageUrl && (
                <div className="w-full h-64 sm:h-72 relative overflow-hidden bg-slate-950">
                  <img
                    src={selectedMemory.imageUrl}
                    alt={selectedMemory.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0f1225] via-transparent to-black/30" />
                  <div className="absolute bottom-4 left-6">
                    <span className="px-3 py-1 rounded-full bg-purple-600/80 text-white text-xs font-semibold backdrop-blur-md">
                      {selectedMemory.tag}
                    </span>
                  </div>
                </div>
              )}

              <div className="p-6 sm:p-8">
                <div className="flex items-center gap-2 text-xs text-purple-300 font-medium mb-1">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>{selectedMemory.date || 'Timeless'}</span>
                </div>

                <h3 className="font-serif-luxury text-2xl sm:text-3xl text-white font-semibold mb-2">
                  {selectedMemory.title}
                </h3>
                <p className="text-sm text-purple-200/80 mb-5 font-display">
                  {selectedMemory.subtitle}
                </p>

                <div className="bg-purple-950/30 border border-purple-500/20 rounded-2xl p-5 mb-6">
                  <p className="text-slate-100 text-sm sm:text-base leading-relaxed font-sans-clean italic">
                    "{selectedMemory.note}"
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-xs text-purple-300 flex items-center gap-1.5">
                    <Heart className="w-3.5 h-3.5 text-purple-400 fill-purple-400/30" />
                    Treasured Memory
                  </span>
                  <button
                    onClick={() => setSelectedMemory(null)}
                    className="px-5 py-2 rounded-full bg-white/10 hover:bg-white/15 text-white text-xs font-medium cursor-pointer transition-colors"
                  >
                    Close
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add Memory Modal with Aesthetic Cover Picker */}
      <AnimatePresence>
        {isAdding && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#101428] border border-purple-500/30 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto"
            >
              <button
                onClick={() => setIsAdding(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <h3 className="font-serif-luxury text-2xl text-white font-semibold mb-1">
                Add a Personal Memory
              </h3>
              <p className="text-xs text-slate-400 mb-6">
                Capture an inside joke, funny moment, or unforgettable night.
              </p>

              <form onSubmit={handleSaveMemory} className="space-y-4 text-left">
                {/* Visual Cover Selection */}
                <div>
                  <label className="block text-xs font-medium text-purple-300 mb-2">
                    Choose an Aesthetic Cover *
                  </label>
                  <div className="grid grid-cols-5 gap-2 mb-2">
                    {CUTE_DESIGNS.map((design) => {
                      const isSelected = selectedCoverUrl === design.url && !customImageUrl;
                      return (
                        <button
                          type="button"
                          key={design.id}
                          onClick={() => {
                            setSelectedCoverUrl(design.url);
                            setCustomImageUrl('');
                          }}
                          className={`relative aspect-square rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${
                            isSelected
                              ? 'border-purple-400 ring-2 ring-purple-500/50 scale-105'
                              : 'border-white/10 hover:border-purple-400/40 opacity-70 hover:opacity-100'
                          }`}
                          title={design.name}
                        >
                          <img
                            src={design.url}
                            alt={design.name}
                            className="w-full h-full object-cover"
                          />
                          {isSelected && (
                            <div className="absolute inset-0 bg-purple-900/40 flex items-center justify-center">
                              <Check className="w-4 h-4 text-white" />
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Moment Title *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Laughing at 2 AM about the funniest story"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-purple-500/20 text-white text-sm focus:outline-none focus:border-purple-400"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Category Tag
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Funny Moments"
                      value={newTag}
                      onChange={(e) => setNewTag(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-purple-500/20 text-white text-sm focus:outline-none focus:border-purple-400"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Context / Time
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 2 AM"
                      value={newDate}
                      onChange={(e) => setNewDate(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-purple-500/20 text-white text-sm focus:outline-none focus:border-purple-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Subtitle
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. When we couldn't stop laughing"
                    value={newSubtitle}
                    onChange={(e) => setNewSubtitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-purple-500/20 text-white text-sm focus:outline-none focus:border-purple-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Memory Note *
                  </label>
                  <textarea
                    required
                    rows={3}
                    placeholder="Write what happened and why it makes you smile..."
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-purple-500/20 text-white text-sm focus:outline-none focus:border-purple-400 resize-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    Or Paste Custom Image URL (optional)
                  </label>
                  <input
                    type="url"
                    placeholder="https://..."
                    value={customImageUrl}
                    onChange={(e) => setCustomImageUrl(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-white/5 border border-purple-500/20 text-white text-xs focus:outline-none focus:border-purple-400"
                  />
                </div>

                <div className="pt-3 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsAdding(false)}
                    className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-violet-600 text-white text-xs font-semibold shadow-md shadow-purple-600/30 cursor-pointer"
                  >
                    Save Moment
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
