import { useState } from 'react';
import { motion } from 'motion/react';
import {
  Sparkles,
  Diamond,
  ArrowRight,
  Sun,
  Smile,
  Zap,
  Home,
  Stars,
  Shield,
  Eye,
  Flame,
  Heart,
  Music,
  CheckCircle,
  Moon,
  ShieldAlert,
  ShieldCheck
} from 'lucide-react';
import { ReasonItem, RelationshipType } from '../types';
import { soundEngine } from '../utils/audio';

interface ReasonsWhyYouAreRareProps {
  reasons: ReasonItem[];
  recipientName: string;
  relationship: RelationshipType;
  onNext: () => void;
}

export default function ReasonsWhyYouAreRare({
  reasons,
  recipientName,
  relationship,
  onNext,
}: ReasonsWhyYouAreRareProps) {
  const [unlockedIds, setUnlockedIds] = useState<Set<string>>(new Set());

  const toggleUnlock = (id: string) => {
    soundEngine.playChime(783.99);
    setUnlockedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const getIcon = (iconName: string) => {
    switch (iconName.toLowerCase()) {
      case 'moon':
        return <Moon className="w-5 h-5 text-purple-300" />;
      case 'shieldheart':
        return <Heart className="w-5 h-5 text-fuchsia-300" />;
      case 'sun':
        return <Sun className="w-5 h-5 text-amber-300" />;
      case 'smile':
        return <Smile className="w-5 h-5 text-purple-200" />;
      case 'zap':
        return <Zap className="w-5 h-5 text-yellow-300" />;
      case 'home':
        return <Home className="w-5 h-5 text-emerald-300" />;
      case 'stars':
        return <Stars className="w-5 h-5 text-purple-300" />;
      case 'shield':
        return <Shield className="w-5 h-5 text-violet-300" />;
      case 'eye':
        return <Eye className="w-5 h-5 text-indigo-300" />;
      case 'flame':
        return <Flame className="w-5 h-5 text-orange-300" />;
      case 'music':
        return <Music className="w-5 h-5 text-purple-300" />;
      case 'heart':
        return <Heart className="w-5 h-5 text-pink-300 fill-pink-300/30" />;
      default:
        return <Sparkles className="w-5 h-5 text-purple-300" />;
    }
  };

  const getSubheading = () => {
    if (relationship === 'partner') {
      return `Six of a million reasons why you are the best part of my days and someone I fall for more each passing day.`;
    }
    if (relationship === 'crush') {
      return `The quiet, magnetic things about you that make it impossible not to look forward to every day.`;
    }
    return `Why having you in my life is the greatest thing in the world.`;
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-10 relative z-10">
      {/* Section Header */}
      <div className="text-center max-w-2xl mx-auto mb-12">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-purple-500/15 border border-purple-500/30 text-purple-300 text-xs font-semibold uppercase tracking-widest mb-3"
        >
          <Diamond className="w-3.5 h-3.5 text-purple-400" />
          <span>Chapter 02 &bull; What Makes You Rare</span>
        </motion.div>
        <motion.h2
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl font-semibold text-white tracking-tight mb-4"
        >
          Why You Are Incomparable
        </motion.h2>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-slate-300 text-base leading-relaxed"
        >
          {getSubheading()} Tap any card to highlight and reflect.
        </motion.p>
      </div>

      {/* Grid of Reasons */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reasons.map((reason, index) => {
          const isUnlocked = unlockedIds.has(reason.id);

          return (
            <motion.div
              key={reason.id}
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.08 + 0.15 }}
              whileHover={{ y: -6 }}
              onClick={() => toggleUnlock(reason.id)}
              className={`relative bg-[#0f1225]/85 border transition-all duration-300 rounded-2xl p-6 backdrop-blur-xl shadow-xl cursor-pointer group flex flex-col justify-between min-h-[220px] ${
                isUnlocked
                  ? 'border-purple-400/60 shadow-purple-900/30 bg-[#141832]'
                  : 'border-purple-500/20 hover:border-purple-400/40 hover:shadow-purple-950/40'
              }`}
            >
              <div>
                {/* Top bar: Number & Category */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <span className="font-serif-luxury font-bold text-xs text-purple-300 tracking-widest">
                      {reason.number}
                    </span>
                    <span className="text-[11px] uppercase tracking-wider text-purple-200/80 px-2.5 py-0.5 rounded-full bg-purple-500/15 border border-purple-500/25">
                      {reason.category}
                    </span>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-purple-500/15 border border-purple-500/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                    {getIcon(reason.icon)}
                  </div>
                </div>

                {/* Title */}
                <h3 className="font-display font-semibold text-lg text-white mb-2 group-hover:text-purple-200 transition-colors">
                  {reason.title}
                </h3>

                {/* Body detail */}
                <p className="text-sm text-slate-300 font-sans-clean leading-relaxed">
                  {reason.detail}
                </p>
              </div>

              {/* Status / Reveal indicator */}
              <div className="mt-5 pt-3 border-t border-purple-500/15 flex items-center justify-between text-xs">
                <span className="text-slate-400 flex items-center gap-1.5">
                  {isUnlocked ? (
                    <>
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-300 font-medium">Unlocked</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                      <span className="text-purple-300/80">Tap to highlight</span>
                    </>
                  )}
                </span>
                <span className="text-purple-300 text-xs font-semibold group-hover:translate-x-0.5 transition-transform">
                  {isUnlocked ? 'Reflected' : 'Read more &rarr;'}
                </span>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Continue CTA */}
      <div className="mt-14 text-center">
        <button
          onClick={() => {
            soundEngine.playTone(587.33, 0.4, 0.06);
            onNext();
          }}
          className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white font-medium text-sm tracking-wide shadow-lg shadow-purple-900/40 hover:shadow-purple-600/50 transition-all cursor-pointer"
        >
          <span>Proceed to The Candle & Wish Ceremony</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
