/**
 * Procedural Web Audio API soundscape generator.
 * Zero external audio dependencies - 100% self-contained, offline-ready, responsive,
 * creating gentle, deeply romantic celestial chords, melodies, chimes, and interaction SFX.
 */

export type RomanticTrackId = 'midnight_waltz' | 'starlight_melody' | 'late_night_whispers';

export interface MusicTrackInfo {
  id: RomanticTrackId;
  name: string;
  vibe: string;
  description: string;
}

export const ROMANTIC_TRACKS: MusicTrackInfo[] = [
  {
    id: 'starlight_melody',
    name: 'Starlight Romance',
    vibe: 'Tender & Cinematic',
    description: 'Gentle piano-like arpeggios with an emotional romantic melody line.',
  },
  {
    id: 'midnight_waltz',
    name: 'Midnight Love Waltz',
    vibe: 'Dreamy & Nostalgic',
    description: 'Warm, slow 3/4 waltz arpeggios that feel like late-night talks.',
  },
  {
    id: 'late_night_whispers',
    name: 'Late-Night Whispers',
    vibe: 'Intimate & Ambient',
    description: 'Deep, comforting twilight chords evoking soft 2 AM conversations.',
  },
];

class CosmicSoundEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private ambientTimer: number | null = null;
  private isPlayingAmbient: boolean = false;
  private currentTrack: RomanticTrackId = 'starlight_melody';
  private stepIndex: number = 0;
  private listeners: Array<(track: RomanticTrackId) => void> = [];

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.isMuted) {
      this.stopAmbient();
    } else {
      this.startAmbient();
    }
    return this.isMuted;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public getCurrentTrack(): RomanticTrackId {
    return this.currentTrack;
  }

  public setTrack(trackId: RomanticTrackId) {
    this.currentTrack = trackId;
    this.stepIndex = 0;
    this.notifyListeners();
    if (this.isPlayingAmbient && !this.isMuted) {
      this.stopAmbient();
      this.startAmbient();
    }
  }

  public onTrackChange(callback: (track: RomanticTrackId) => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== callback);
    };
  }

  private notifyListeners() {
    this.listeners.forEach((l) => l(this.currentTrack));
  }

  public startAmbient() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;
    this.isPlayingAmbient = true;

    if (this.ambientTimer) clearInterval(this.ambientTimer);

    // Play initial phrase
    this.playTrackPhrase();

    // Rhythmic intervals depending on track
    const intervalMs = this.currentTrack === 'midnight_waltz' ? 3800 : 4200;

    this.ambientTimer = window.setInterval(() => {
      if (!this.isMuted && this.isPlayingAmbient) {
        this.playTrackPhrase();
      }
    }, intervalMs);
  }

  public stopAmbient() {
    this.isPlayingAmbient = false;
    if (this.ambientTimer) {
      clearInterval(this.ambientTimer);
      this.ambientTimer = null;
    }
  }

  /**
   * Plays a romantic phrase based on the currently selected track
   */
  private playTrackPhrase() {
    if (!this.ctx || this.isMuted) return;

    if (this.currentTrack === 'starlight_melody') {
      // Cinematic Romantic Progression: Dbmaj7 -> Bbm9 -> Gbmaj7 -> Absus4
      const chords = [
        { bass: 138.59, notes: [277.18, 329.63, 415.30, 523.25], lead: [554.37, 659.25] }, // Db
        { bass: 116.54, notes: [233.08, 277.18, 349.23, 440.00], lead: [466.16, 523.25] }, // Bbm
        { bass: 92.50,  notes: [185.00, 277.18, 329.63, 415.30], lead: [554.37, 659.25] }, // Gb
        { bass: 103.83, notes: [207.65, 311.13, 349.23, 466.16], lead: [523.25, 466.16] }  // Ab
      ];

      const step = chords[this.stepIndex % chords.length];
      this.stepIndex++;

      // Bass note
      this.playWarmPiano(step.bass, 3.8, 0.045);

      // Delicate rolling arpeggio
      step.notes.forEach((freq, idx) => {
        setTimeout(() => {
          this.playWarmPiano(freq, 2.8, 0.035);
        }, 180 + idx * 160);
      });

      // Romantic singing top melody note
      step.lead.forEach((freq, idx) => {
        setTimeout(() => {
          this.playSingingNote(freq, 2.5, 0.04);
        }, 900 + idx * 450);
      });

    } else if (this.currentTrack === 'midnight_waltz') {
      // Tender Romantic Waltz Progression (3/4 feel): Fmaj9 -> Dm9 -> Bbmaj9 -> C7sus4
      const waltzChords = [
        { bass: 174.61, chord1: [261.63, 329.63], chord2: [349.23, 440.00, 523.25] }, // F
        { bass: 146.83, chord1: [220.00, 293.66], chord2: [349.23, 440.00, 523.25] }, // Dm
        { bass: 116.54, chord1: [233.08, 293.66], chord2: [349.23, 466.16, 587.33] }, // Bb
        { bass: 130.81, chord1: [261.63, 349.23], chord2: [392.00, 466.16, 523.25] }  // C
      ];

      const waltz = waltzChords[this.stepIndex % waltzChords.length];
      this.stepIndex++;

      // Beat 1: Bass
      this.playWarmPiano(waltz.bass, 3.2, 0.05);

      // Beat 2: Mid harmony
      setTimeout(() => {
        waltz.chord1.forEach(f => this.playWarmPiano(f, 2.0, 0.03));
      }, 350);

      // Beat 3: Top harmony
      setTimeout(() => {
        waltz.chord2.forEach(f => this.playWarmPiano(f, 2.2, 0.032));
      }, 700);

    } else {
      // Late Night Whispers: Deep, lush, comforting ambient pads
      const ambientChords = [
        [138.59, 207.65, 277.18, 329.63, 415.30], // Db maj9
        [174.61, 261.63, 311.13, 392.00, 523.25], // F min9
        [155.56, 233.08, 277.18, 349.23, 466.16], // Eb sus4
        [185.00, 277.18, 329.63, 440.00, 554.37]  // Gb maj7#11
      ];

      const chord = ambientChords[this.stepIndex % ambientChords.length];
      this.stepIndex++;

      chord.forEach((freq, idx) => {
        setTimeout(() => {
          this.playTone(freq, 4.5, 0.03, 'sine');
        }, idx * 140);
      });
    }
  }

  /**
   * Warm piano / music-box hybrid tone (sine + gentle triangle overtone with exponential decay)
   */
  public playWarmPiano(freq: number, duration: number = 2.0, volume: number = 0.04) {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const overtone = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1400, now);
      filter.frequency.exponentialRampToValueAtTime(300, now + duration);

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now);

      overtone.type = 'triangle';
      overtone.frequency.setValueAtTime(freq * 2, now);

      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.linearRampToValueAtTime(volume, now + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      osc.connect(filter);
      overtone.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      overtone.start(now);
      osc.stop(now + duration);
      overtone.stop(now + duration);
    } catch {
      // AudioContext policy suppression fallback
    }
  }

  /**
   * Singing melodic note with subtle vibrato for romantic highlights
   */
  public playSingingNote(freq: number, duration: number = 2.2, volume: number = 0.035) {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now);

      // Subtle warm pitch vibrato
      osc.frequency.setTargetAtTime(freq + 1.2, now + 0.2, 0.1);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(volume, now + 0.12);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + duration);
    } catch {
      // Ignore
    }
  }

  public playTone(freq: number, duration: number = 1.5, volume: number = 0.08, type: OscillatorType = 'sine') {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, now);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(volume, now + 0.15);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + duration);
    } catch {
      // AudioContext policy suppression fallback
    }
  }

  /**
   * Delicate crystal shimmer for clicks, unboxing, or hover
   */
  public playChime(freq: number = 587.33) {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now);

      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.8);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.8);
    } catch {
      // Silent catch
    }
  }

  /**
   * Special Romantic Music Box Lullaby for the Vault
   */
  public playLoveLullaby() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    // Sweet, emotional love motif:
    // C5 - E5 - G5 - B5 - A5 - G5 - E5 - D5 - C5
    const motif = [
      { freq: 523.25, delay: 0 },
      { freq: 659.25, delay: 260 },
      { freq: 783.99, delay: 520 },
      { freq: 987.77, delay: 840 },
      { freq: 880.00, delay: 1200 },
      { freq: 783.99, delay: 1540 },
      { freq: 659.25, delay: 1880 },
      { freq: 587.33, delay: 2220 },
      { freq: 523.25, delay: 2600 },
      { freq: 1046.50, delay: 3000 }
    ];

    motif.forEach(note => {
      setTimeout(() => {
        this.playWarmPiano(note.freq, 1.8, 0.07);
      }, note.delay);
    });
  }

  /**
   * Sound effect for blowing out candle (soft breath swoosh)
   */
  public playBreathBlow() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const bufferSize = this.ctx.sampleRate * 1.2;
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1; // White noise
      }

      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(600, this.ctx.currentTime);
      filter.frequency.exponentialRampToValueAtTime(120, this.ctx.currentTime + 1.1);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.01, this.ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.12, this.ctx.currentTime + 0.2);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 1.1);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noise.start();
    } catch {
      // Ignore
    }
  }

  /**
   * Celebratory chime arpeggio (Happy Birthday opening motif)
   */
  public playCelebrationFanfare() {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx) return;

    const notes = [
      { freq: 261.63, delay: 0 },
      { freq: 261.63, delay: 240 },
      { freq: 293.66, delay: 480 },
      { freq: 261.63, delay: 780 },
      { freq: 349.23, delay: 1080 },
      { freq: 329.63, delay: 1400 },
      { freq: 523.25, delay: 1800 },
      { freq: 659.25, delay: 2100 },
      { freq: 783.99, delay: 2400 },
      { freq: 1046.50, delay: 2700 }
    ];

    notes.forEach(n => {
      setTimeout(() => {
        this.playTone(n.freq, 1.4, 0.09, 'triangle');
      }, n.delay);
    });
  }

  /**
   * Wax seal break / unwrap snap
   */
  public playUnwrapSound() {
    if (this.isMuted) return;
    this.playTone(440, 0.3, 0.05, 'sine');
    setTimeout(() => this.playChime(880), 80);
    setTimeout(() => this.playChime(1318.5), 180);
  }
}

export const soundEngine = new CosmicSoundEngine();
