export type RelationshipType = 'crush' | 'partner' | 'best_friend';

export interface MemoryItem {
  id: string;
  title: string;
  subtitle: string;
  date?: string;
  tag: string;
  note: string;
  imageUrl?: string;
  iconName: string;
}

export interface ReasonItem {
  id: string;
  number: string;
  title: string;
  detail: string;
  category: string;
  icon: string;
}

export interface CouponItem {
  id: string;
  title: string;
  desc: string;
  tag: string;
  icon: string;
  redeemed?: boolean;
}

export interface GreetingConfig {
  recipientName: string;
  senderName: string;
  relationship: RelationshipType;
  nickname: string;
  birthdayDate: string;
  ageDisplay: string;
  letter: {
    salutation: string;
    paragraphs: string[];
    closing: string;
    postScript?: string;
  };
  memories: MemoryItem[];
  reasons: ReasonItem[];
  coupons: CouponItem[];
  secretCodeMessage: string;
  wishingStarDefault: string;
}

export type ChapterId = 'gateway' | 'constellation' | 'reasons' | 'cake' | 'letter' | 'gift';
