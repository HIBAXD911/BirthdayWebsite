import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import {
  Sparkles,
  Wind,
  Mic,
  MicOff,
  Flame,
  Star,
  ArrowRight,
  Send,
  Heart
} from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface BirthdayCakeCeremonyProps {
  recipientName: string;
  wishingStarDefault: string;
  onNext: () => void;
}

export default function BirthdayCakeCeremony({
  recipientName,
  wishingStarDefault,
  onNext,
}: BirthdayCakeCeremonyProps) {
  const [isExtinguished, setIsExtinguished] = useState(false);
  const [isListeningMic, setIsListeningMic] = useState(false);
  const [micPermissionDenied, setMicPermissionDenied] = useState(false);
  const [wishText, setWishText] = useState('');
  const [wishGranted, setWishGranted] = useState(false);
  const [isShootingWish, setIsShootingWish] = useState(false);

  const audioStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Clean up mic on unmount
  useEffect(() => {
    return () => {
      stopMicListening();
    };
  }, []);

  const triggerBlowOut = () => {
    if (isExtinguished) return;

    soundEngine.playBreathBlow();
    setIsExtinguished(true);
    stopMicListening();

    // Trigger celebration fanfare
    setTimeout(() => {
      soundEngine.playCelebrationFanfare();
    }, 400);

    // Multi-stage confetti celebration with purple, violet, gold, and pink
    try {
      confetti({
        particleCount: 110,
        spread: 80,
        origin: { y: 0.6 },
        colors: ['#a855f7', '#c084fc', '#e9d5ff', '#fbbf24', '#f472b6', '#ffffff'],
      });

      setTimeout(() => {
        confetti({
          particleCount: 70,
          angle: 60,
          spread: 60,
          origin: { x: 0.1, y: 0.7 },
          colors: ['#d8b4fe', '#c084fc', '#fbcfe8', '#fef08a'],
        });
      }, 300);

      setTimeout(() => {
        confetti({
          particleCount: 70,
          angle: 120,
          spread: 60,
          origin: { x: 0.9, y: 0.7 },
          colors: ['#d8b4fe', '#c084fc', '#fbcfe8', '#fef08a'],
        });
      }, 600);
    } catch {
      // Ignore if canvas-confetti fails
    }
  };

  const startMicListening = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioStreamRef.current = stream;
      setIsListeningMic(true);
      setMicPermissionDenied(false);

      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;

      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 512;
      analyser.smoothingTimeConstant = 0.2;
      source.connect(analyser);

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const checkVolume = () => {
        if (!analyser) return;
        analyser.getByteFrequencyData(dataArray);

        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        const average = sum / bufferLength;

        // Threshold for human breath / blow into mic
        if (average > 38) {
          triggerBlowOut();
          return;
        }

        animFrameRef.current = requestAnimationFrame(checkVolume);
      };

      checkVolume();
    } catch (err) {
      setMicPermissionDenied(true);
      setIsListeningMic(false);
    }
  };

  const stopMicListening = () => {
    setIsListeningMic(false);
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (audioStreamRef.current) {
      audioStreamRef.current.getTracks().forEach((t) => t.stop());
      audioStreamRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
  };

  const handleSendWish = (e: React.FormEvent) => {
    e.preventDefault();
    soundEngine.playTone(880, 0.4, 0.08);
    setIsShootingWish(true);

    setTimeout(() => {
      soundEngine.playChime(1046.5);
      setWishGranted(true);
      setIsShootingWish(false);

      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.4 },
          colors: ['#fbbf24', '#fef08a', '#c084fc'],
        });
      } catch {
        // Ignore
      }
    }, 900);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-10 relative z-10">
      {/* Section Header */}
      <div className="text-center max-w-xl mx-auto mb-10">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-purple-500/15 border border-purple-500/30 text-purple-300 text-xs font-semibold uppercase tracking-widest mb-3"
        >
          <Flame className="w-3.5 h-3.5 text-purple-400" />
          <span>Chapter 03 &bull; Candle & Wish Ceremony</span>
        </motion.div>
        <motion.h2
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="font-serif-luxury text-3xl sm:text-4xl md:text-5xl font-semibold text-white tracking-tight mb-3"
        >
          Make a Wish, {recipientName}
        </motion.h2>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-slate-300 text-sm sm:text-base leading-relaxed"
        >
          A single sacred flame awaits. Blow into your microphone or tap the flame to extinguish it and release your heartfelt wish into the night sky.
        </motion.p>
      </div>

      {/* Main Ceremony Card */}
      <div className="bg-[#0e1124]/90 border border-purple-500/30 rounded-3xl p-8 sm:p-12 backdrop-blur-2xl shadow-2xl relative overflow-hidden text-center max-w-2xl mx-auto">
        {/* Glow ambient background behind the cake */}
        <div
          className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 rounded-full transition-opacity duration-1000 pointer-events-none ${
            isExtinguished
              ? 'opacity-0 bg-transparent'
              : 'opacity-40 bg-purple-600/25 blur-3xl'
          }`}
        />

        {/* 3D Modern Birthday Cake Illustration */}
        <div className="relative w-64 h-64 mx-auto mb-8 flex flex-col items-center justify-end select-none">
          {/* Candle & Flame */}
          <div className="relative flex flex-col items-center z-20 mb-[-6px]">
            {/* The Flame */}
            {!isExtinguished ? (
              <div
                onClick={triggerBlowOut}
                className="flame-flicker cursor-pointer relative w-6 h-10 mb-1 flex items-center justify-center"
                title="Tap to blow out!"
              >
                {/* Core bright glow */}
                <div className="w-5 h-9 rounded-[50%_50%_35%_35%] bg-gradient-to-t from-orange-500 via-amber-300 to-white shadow-[0_0_24px_rgba(251,191,36,0.9)]" />
                {/* Inner violet/blue base */}
                <div className="absolute bottom-0 w-2.5 h-3 rounded-full bg-violet-400/80 blur-[1px]" />
              </div>
            ) : (
              /* Smoke Drift Animation */
              <motion.div
                initial={{ opacity: 0.8, y: 0, scale: 0.8 }}
                animate={{ opacity: 0, y: -45, scale: 1.8, x: [0, 8, -6, 12] }}
                transition={{ duration: 2.2, ease: 'easeOut' }}
                className="w-4 h-8 bg-purple-300/40 blur-[3px] rounded-full mb-1"
              />
            )}

            {/* Candle Wick */}
            <div className="w-1 h-3 bg-slate-600 rounded-t-sm" />

            {/* Candle Body */}
            <div className="w-5 h-16 rounded-t-md bg-gradient-to-r from-purple-500 via-violet-500 to-indigo-600 shadow-md border-t border-purple-300/40 relative overflow-hidden">
              {/* Gold spiral stripe on candle */}
              <div className="absolute inset-0 opacity-30 bg-[linear-gradient(45deg,transparent_25%,rgba(255,255,255,0.7)_50%,transparent_75%)] bg-[length:12px_12px]" />
            </div>
          </div>

          {/* Top Layer of Cake */}
          <div className="w-36 h-14 rounded-2xl bg-gradient-to-b from-[#2d1b46] to-[#1c102c] border border-purple-400/40 relative z-10 shadow-lg flex items-center justify-center">
            {/* Lavender / Cream Frosting drips */}
            <div className="absolute -top-1.5 inset-x-2 h-4 bg-gradient-to-r from-purple-200 via-violet-100 to-purple-200 rounded-full shadow-sm flex justify-around px-2">
              <span className="w-2 h-3 bg-purple-200 rounded-full mt-1.5" />
              <span className="w-2 h-4 bg-purple-200 rounded-full mt-1" />
              <span className="w-2 h-2.5 bg-purple-200 rounded-full mt-1.5" />
              <span className="w-2 h-3.5 bg-purple-200 rounded-full mt-1" />
            </div>
            <span className="text-[11px] font-display uppercase tracking-widest text-purple-300 font-semibold mt-2">
              {recipientName}
            </span>
          </div>

          {/* Bottom Layer of Cake */}
          <div className="w-52 h-18 rounded-3xl bg-gradient-to-b from-[#3a1d56] via-[#26123a] to-[#170a25] border border-purple-500/40 relative z-0 -mt-2 shadow-2xl flex flex-col justify-end pb-3 items-center">
            {/* Lower Frosting Line */}
            <div className="w-48 h-2.5 bg-gradient-to-r from-amber-200 via-purple-200 to-amber-200 rounded-full shadow-sm" />
          </div>

          {/* Elegant Stand */}
          <div className="w-64 h-5 rounded-full bg-gradient-to-r from-slate-700 via-purple-900 to-slate-800 border-t border-purple-400/30 shadow-2xl -mt-1" />
        </div>

        {/* Action Controls when candle is lit */}
        {!isExtinguished ? (
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={triggerBlowOut}
              className="w-full sm:w-auto px-7 py-3.5 rounded-full bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-medium text-sm tracking-wide shadow-lg shadow-purple-900/40 flex items-center justify-center gap-2 cursor-pointer transition-all duration-300"
            >
              <Wind className="w-4 h-4" />
              <span>Tap to Blow Out Candle</span>
            </button>

            {/* Microphone Blow Detection Toggle */}
            <button
              onClick={isListeningMic ? stopMicListening : startMicListening}
              className={`w-full sm:w-auto px-5 py-3.5 rounded-full border text-xs font-medium flex items-center justify-center gap-2 transition-all cursor-pointer ${
                isListeningMic
                  ? 'bg-purple-500/25 border-purple-400/60 text-purple-200 animate-pulse'
                  : 'bg-white/5 border-purple-500/25 hover:bg-white/10 text-slate-300'
              }`}
            >
              {isListeningMic ? (
                <>
                  <Mic className="w-4 h-4 text-purple-300" />
                  <span>Blow into Mic now!</span>
                </>
              ) : (
                <>
                  <MicOff className="w-4 h-4 text-slate-400" />
                  <span>Enable Mic to Blow</span>
                </>
              )}
            </button>
          </div>
        ) : (
          /* Wish Fulfillment & Input Section */
          <AnimatePresence>
            {!wishGranted ? (
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4"
              >
                <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-purple-500/20 border border-purple-500/35 text-purple-200 text-xs font-medium mb-4">
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>The Flame Has Vanished &bull; Make Your Secret Wish</span>
                </div>

                <form onSubmit={handleSendWish} className="max-w-md mx-auto">
                  <div className="relative mb-3">
                    <input
                      type="text"
                      placeholder={`e.g., "${wishingStarDefault}"`}
                      value={wishText}
                      onChange={(e) => setWishText(e.target.value)}
                      className="w-full px-4 py-3.5 pr-12 rounded-2xl bg-white/5 border border-purple-500/30 focus:border-purple-400 text-white placeholder-slate-500 text-sm focus:outline-none transition-colors"
                    />
                    <button
                      type="submit"
                      disabled={isShootingWish}
                      className="absolute right-2 top-2 bottom-2 px-3.5 rounded-xl bg-gradient-to-r from-purple-600 to-violet-600 text-white flex items-center justify-center cursor-pointer hover:opacity-90 disabled:opacity-50"
                      title="Release Wish"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-xs text-slate-400">
                    Your wish will remain private and sealed into the constellation.
                  </p>
                </form>
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mt-4 p-6 rounded-2xl bg-gradient-to-b from-purple-900/20 to-transparent border border-purple-500/30 text-center"
              >
                <div className="w-12 h-12 rounded-full bg-purple-500/20 text-purple-300 mx-auto flex items-center justify-center mb-3">
                  <Star className="w-6 h-6 fill-purple-300/30" />
                </div>
                <h3 className="font-serif-luxury text-2xl text-white font-semibold mb-2">
                  Your Wish Is Carried by the Stars
                </h3>
                <p className="text-slate-300 text-sm max-w-sm mx-auto mb-6">
                  May this entire year bring you every bit of happiness, love, warmth, and late-night laughter you deserve. 🤍
                </p>
                <button
                  onClick={() => {
                    soundEngine.playTone(659.25, 0.5, 0.07);
                    onNext();
                  }}
                  className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white font-medium text-sm tracking-wide shadow-lg shadow-purple-900/40 cursor-pointer transition-all"
                >
                  <span>Read Your Birthday Letter</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        )}

        {micPermissionDenied && (
          <p className="text-xs text-purple-300/80 mt-3">
            Microphone access was denied. You can tap the "Tap to Blow Out Candle" button instead!
          </p>
        )}
      </div>
    </div>
  );
}
