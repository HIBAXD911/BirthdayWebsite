import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  Camera,
  Diamond,
  Flame,
  Feather,
  Gift,
  Volume2,
  VolumeX,
  Sliders,
  Download,
  Music,
  Check,
  ChevronUp
} from 'lucide-react';
import { ChapterId } from '../types';
import { soundEngine, ROMANTIC_TRACKS, RomanticTrackId } from '../utils/audio';

interface NavigationDockProps {
  activeChapter: ChapterId;
  onSelectChapter: (chapter: ChapterId) => void;
  isAudioMuted: boolean;
  onToggleAudio: () => void;
  onOpenCustomize: () => void;
  onDownloadHtml: () => void;
  bgMode: 'celestial' | 'neon-stars';
  onToggleBgMode: () => void;
}

export default function NavigationDock({
  activeChapter,
  onSelectChapter,
  isAudioMuted,
  onToggleAudio,
  onOpenCustomize,
  onDownloadHtml,
  bgMode,
  onToggleBgMode,
}: NavigationDockProps) {
  const [showMusicMenu, setShowMusicMenu] = useState(false);
  const [currentTrack, setCurrentTrack] = useState<RomanticTrackId>(soundEngine.getCurrentTrack());
  const menuRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const unsub = soundEngine.onTrackChange((t) => setCurrentTrack(t));
    return unsub;
  }, []);

  // Close menu on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setShowMusicMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const chapters: Array<{ id: ChapterId; label: string; icon: React.ReactNode }> = [
    { id: 'gateway', label: 'Gateway', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'constellation', label: 'Moments', icon: <Camera className="w-4 h-4" /> },
    { id: 'reasons', label: 'Rare', icon: <Diamond className="w-4 h-4" /> },
    { id: 'cake', label: 'Candle', icon: <Flame className="w-4 h-4" /> },
    { id: 'letter', label: 'Letter', icon: <Feather className="w-4 h-4" /> },
    { id: 'gift', label: 'Vault', icon: <Gift className="w-4 h-4" /> },
  ];

  const handleChapterClick = (id: ChapterId) => {
    soundEngine.playTone(600, 0.25, 0.04);
    onSelectChapter(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectTrack = (trackId: RomanticTrackId) => {
    soundEngine.playChime(783.99);
    soundEngine.setTrack(trackId);
    setShowMusicMenu(false);
  };

  return (
    <div className="fixed bottom-5 inset-x-0 z-40 flex justify-center px-3 pointer-events-none">
      <div className="relative pointer-events-auto" ref={menuRef}>
        {/* Music Switcher Popover */}
        <AnimatePresence>
          {showMusicMenu && (
            <motion.div
              initial={{ opacity: 0, y: 15, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              className="absolute bottom-full mb-3 left-1/2 -translate-x-1/2 w-72 sm:w-80 p-3.5 rounded-2xl bg-[#0e1022]/95 border border-purple-500/30 backdrop-blur-2xl shadow-2xl shadow-purple-950/60 z-50 text-left"
            >
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-purple-500/20">
                <span className="text-xs font-semibold text-purple-200 flex items-center gap-1.5">
                  <Music className="w-3.5 h-3.5 text-purple-400" />
                  Romantic Music Selection
                </span>
                <span className="text-[10px] text-purple-400/80 uppercase tracking-widest font-mono">
                  Live Synth
                </span>
              </div>

              <div className="space-y-1.5">
                {ROMANTIC_TRACKS.map((track) => {
                  const isCurrent = currentTrack === track.id;
                  return (
                    <button
                      key={track.id}
                      onClick={() => handleSelectTrack(track.id)}
                      className={`w-full p-2.5 rounded-xl border text-left transition-all flex items-start justify-between cursor-pointer ${
                        isCurrent
                          ? 'bg-purple-600/30 border-purple-400 text-white shadow-sm'
                          : 'bg-white/5 border-transparent hover:bg-white/10 hover:border-purple-500/30 text-slate-300'
                      }`}
                    >
                      <div>
                        <div className="flex items-center gap-1.5">
                          <p className="text-xs font-semibold text-white">{track.name}</p>
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300">
                            {track.vibe}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                          {track.description}
                        </p>
                      </div>
                      {isCurrent && <Check className="w-4 h-4 text-purple-300 shrink-0 mt-0.5" />}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Floating Dock Bar */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="bg-[#0b0d1b]/90 border border-purple-500/30 backdrop-blur-2xl rounded-full p-1.5 sm:p-2 shadow-2xl flex items-center gap-1 sm:gap-2 max-w-full overflow-x-auto"
        >
          {/* Chapters list */}
          <div className="flex items-center gap-1">
            {chapters.map((chap) => {
              const isActive = activeChapter === chap.id;
              return (
                <button
                  key={chap.id}
                  onClick={() => handleChapterClick(chap.id)}
                  className={`relative px-3 sm:px-3.5 py-2 rounded-full text-xs font-medium flex items-center gap-1.5 transition-all duration-300 cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'text-white bg-gradient-to-r from-purple-600 to-violet-600 shadow-md shadow-purple-900/40'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                  title={chap.label}
                >
                  {chap.icon}
                  <span className="hidden sm:inline font-display">{chap.label}</span>
                </button>
              );
            })}
          </div>

          {/* Separator */}
          <div className="h-5 w-[1px] bg-purple-500/20 mx-0.5 sm:mx-1" />

          {/* Audio control button */}
          <button
            onClick={onToggleAudio}
            className={`p-2 sm:px-3 sm:py-2 rounded-full text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
              !isAudioMuted
                ? 'text-purple-300 bg-purple-500/20 border border-purple-500/30'
                : 'text-slate-400 hover:text-white bg-white/5'
            }`}
            title={isAudioMuted ? 'Unmute Ambient Sound' : 'Mute Ambient Sound'}
          >
            {isAudioMuted ? (
              <VolumeX className="w-4 h-4 text-slate-400" />
            ) : (
              <div className="flex items-center gap-1">
                <Volume2 className="w-4 h-4 text-purple-400" />
                {/* Animated sound wave bars */}
                <span className="hidden md:flex items-center gap-0.5 h-3">
                  <span className="w-0.5 h-2 bg-purple-400 rounded-full animate-pulse" />
                  <span className="w-0.5 h-3 bg-purple-300 rounded-full animate-pulse [animation-delay:150ms]" />
                  <span className="w-0.5 h-1.5 bg-purple-400 rounded-full animate-pulse [animation-delay:300ms]" />
                </span>
              </div>
            )}
          </button>

          {/* Music Switcher Button */}
          <button
            onClick={() => setShowMusicMenu((prev) => !prev)}
            className={`p-2 sm:px-3 sm:py-2 rounded-full text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
              showMusicMenu
                ? 'text-white bg-purple-600/40 border border-purple-400/50'
                : 'text-purple-300 hover:text-white bg-purple-500/15 border border-purple-500/25'
            }`}
            title="Change Romantic Music Theme"
          >
            <Music className="w-4 h-4 text-purple-400" />
            <span className="hidden md:inline text-[11px] font-semibold">Romantic Music</span>
            <ChevronUp
              className={`w-3 h-3 text-purple-400 transition-transform ${
                showMusicMenu ? 'rotate-180' : ''
              }`}
            />
          </button>

          {/* Background Aesthetic Toggle Button */}
          <button
            onClick={onToggleBgMode}
            className={`p-2 sm:px-3 sm:py-2 rounded-full text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
              bgMode === 'neon-stars'
                ? 'text-fuchsia-200 bg-fuchsia-600/30 border border-fuchsia-400/50 shadow-sm'
                : 'text-purple-300 hover:text-white bg-purple-500/10 border border-purple-500/20'
            }`}
            title={bgMode === 'neon-stars' ? 'Switch to Celestial Deep Cosmos' : 'Switch to Neon Checkered Stars (From Video)'}
          >
            <Sparkles className="w-4 h-4 text-fuchsia-400" />
            <span className="hidden lg:inline text-[11px]">
              {bgMode === 'neon-stars' ? 'Neon Stars' : 'Cosmos'}
            </span>
          </button>

          {/* Export Single HTML Button */}
          <button
            onClick={onDownloadHtml}
            className="p-2 sm:px-3 sm:py-2 rounded-full text-xs font-medium text-amber-200 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 flex items-center gap-1.5 transition-all cursor-pointer"
            title="Download as 100% Standalone Single-File HTML"
          >
            <Download className="w-4 h-4 text-amber-300" />
            <span className="hidden lg:inline">Single .HTML</span>
          </button>

          {/* Settings / Personalize Modal trigger */}
          <button
            onClick={onOpenCustomize}
            className="p-2 sm:px-3 sm:py-2 rounded-full text-xs font-medium text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 transition-all cursor-pointer flex items-center gap-1.5"
            title="Personalize Name, Mode & Messages"
          >
            <Sliders className="w-4 h-4 text-purple-400" />
            <span className="hidden lg:inline">Edit</span>
          </button>
        </motion.div>
      </div>
    </div>
  );
}
