import { useEffect, useRef } from 'react';

interface Star {
  x: number;
  y: number;
  radius: number;
  alpha: number;
  baseAlpha: number;
  twinkleSpeed: number;
  twinklePhase: number;
  color: string;
}

interface ShootingStar {
  x: number;
  y: number;
  len: number;
  speed: number;
  angle: number;
  opacity: number;
}

interface NeonFloatingStar {
  x: number;
  y: number;
  size: number;
  speedY: number;
  rot: number;
  rotSpeed: number;
  opacity: number;
  glow: number;
}

interface CosmicBackgroundProps {
  mode?: 'celestial' | 'neon-stars';
}

export default function CosmicBackground({ mode = 'celestial' }: CosmicBackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    // Celestial mode data
    const colors = ['#ffffff', '#e9d5ff', '#d8b4fe', '#c084fc', '#fbcfe8', '#a855f7'];
    const starCount = Math.floor((width * height) / 4200);

    const stars: Star[] = Array.from({ length: starCount }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      radius: Math.random() * 1.6 + 0.3,
      alpha: Math.random() * 0.8 + 0.2,
      baseAlpha: Math.random() * 0.7 + 0.3,
      twinkleSpeed: Math.random() * 0.02 + 0.005,
      twinklePhase: Math.random() * Math.PI * 2,
      color: colors[Math.floor(Math.random() * colors.length)],
    }));

    let shootingStars: ShootingStar[] = [];

    // Neon floating stars mode data (matching user video)
    const neonStars: NeonFloatingStar[] = Array.from({ length: 36 }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      size: Math.random() * 24 + 14,
      speedY: Math.random() * 0.8 + 0.35,
      rot: Math.random() * Math.PI * 2,
      rotSpeed: (Math.random() - 0.5) * 0.02,
      opacity: Math.random() * 0.5 + 0.5,
      glow: Math.random() * 15 + 10,
    }));

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    const shootInterval = setInterval(() => {
      if (mode === 'celestial' && shootingStars.length < 2) {
        shootingStars.push({
          x: Math.random() * width * 0.7 + width * 0.15,
          y: Math.random() * (height * 0.4),
          len: Math.random() * 90 + 50,
          speed: Math.random() * 8 + 6,
          angle: Math.PI / 4 + (Math.random() * 0.2 - 0.1),
          opacity: 1,
        });
      }
    }, 3800);

    // Helper to draw 5-point star
    const drawStarShape = (
      cx: number,
      cy: number,
      spikes: number,
      outerRadius: number,
      innerRadius: number
    ) => {
      let rot = (Math.PI / 2) * 3;
      let x = cx;
      let y = cy;
      const step = Math.PI / spikes;

      ctx.beginPath();
      ctx.moveTo(cx, cy - outerRadius);
      for (let i = 0; i < spikes; i++) {
        x = cx + Math.cos(rot) * outerRadius;
        y = cy + Math.sin(rot) * outerRadius;
        ctx.lineTo(x, y);
        rot += step;

        x = cx + Math.cos(rot) * innerRadius;
        y = cy + Math.sin(rot) * innerRadius;
        ctx.lineTo(x, y);
        rot += step;
      }
      ctx.lineTo(cx, cy - outerRadius);
      ctx.closePath();
    };

    let tick = 0;

    const render = () => {
      tick++;
      ctx.clearRect(0, 0, width, height);

      if (mode === 'neon-stars') {
        // Neon Checkered Background inspired by user video
        ctx.fillStyle = '#1e0836';
        ctx.fillRect(0, 0, width, height);

        const tileSize = 64;
        const cols = Math.ceil(width / tileSize);
        const rows = Math.ceil(height / tileSize);

        for (let r = 0; r < rows; r++) {
          for (let c = 0; c < cols; c++) {
            if ((r + c) % 2 === 0) {
              ctx.fillStyle = 'rgba(112, 26, 179, 0.28)';
              ctx.fillRect(c * tileSize, r * tileSize, tileSize, tileSize);
            } else {
              ctx.fillStyle = 'rgba(74, 14, 122, 0.18)';
              ctx.fillRect(c * tileSize, r * tileSize, tileSize, tileSize);
            }
          }
        }

        // Perspective grid lines / soft radial vignette
        const grad = ctx.createRadialGradient(
          width * 0.5,
          height * 0.5,
          100,
          width * 0.5,
          height * 0.5,
          width * 0.75
        );
        grad.addColorStop(0, 'rgba(192, 132, 252, 0.15)');
        grad.addColorStop(0.6, 'rgba(88, 28, 135, 0.3)');
        grad.addColorStop(1, 'rgba(10, 4, 20, 0.85)');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);

        // Draw floating neon stars (with purple body, bright white inner outline and glow)
        neonStars.forEach((star) => {
          star.y -= star.speedY;
          star.rot += star.rotSpeed;
          if (star.y < -50) {
            star.y = height + 40;
            star.x = Math.random() * width;
          }

          ctx.save();
          ctx.translate(star.x, star.y);
          ctx.rotate(star.rot);

          // Neon purple aura
          ctx.shadowColor = '#d946ef';
          ctx.shadowBlur = 18;
          ctx.fillStyle = 'rgba(217, 70, 239, 0.85)';
          drawStarShape(0, 0, 5, star.size, star.size * 0.45);
          ctx.fill();

          // White inner stroke
          ctx.shadowColor = '#ffffff';
          ctx.shadowBlur = 6;
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 2.5;
          drawStarShape(0, 0, 5, star.size * 0.88, star.size * 0.38);
          ctx.stroke();

          // Soft inner purple fill
          ctx.fillStyle = 'rgba(240, 171, 252, 0.9)';
          drawStarShape(0, 0, 5, star.size * 0.65, star.size * 0.3);
          ctx.fill();

          ctx.restore();
        });
      } else {
        // Deep Royal Purple Celestial Night
        const grad = ctx.createRadialGradient(
          width * 0.5,
          height * 0.35,
          50,
          width * 0.5,
          height * 0.35,
          width * 0.8
        );
        grad.addColorStop(0, 'rgba(88, 28, 135, 0.45)');
        grad.addColorStop(0.45, 'rgba(59, 7, 100, 0.32)');
        grad.addColorStop(0.75, 'rgba(30, 10, 60, 0.15)');
        grad.addColorStop(1, 'rgba(7, 8, 15, 0.0)');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);

        const roseGrad = ctx.createRadialGradient(
          width * 0.8,
          height * 0.75,
          30,
          width * 0.8,
          height * 0.75,
          width * 0.55
        );
        roseGrad.addColorStop(0, 'rgba(126, 34, 206, 0.28)');
        roseGrad.addColorStop(0.6, 'rgba(88, 28, 135, 0.14)');
        roseGrad.addColorStop(1, 'rgba(7, 8, 15, 0.0)');
        ctx.fillStyle = roseGrad;
        ctx.fillRect(0, 0, width, height);

        const lavGrad = ctx.createRadialGradient(
          width * 0.2,
          height * 0.2,
          20,
          width * 0.2,
          height * 0.2,
          width * 0.45
        );
        lavGrad.addColorStop(0, 'rgba(168, 85, 247, 0.16)');
        lavGrad.addColorStop(1, 'rgba(7, 8, 15, 0.0)');
        ctx.fillStyle = lavGrad;
        ctx.fillRect(0, 0, width, height);

        // Render celestial stars
        stars.forEach((s) => {
          s.twinklePhase += s.twinkleSpeed;
          const currentAlpha = Math.max(
            0.1,
            s.baseAlpha + Math.sin(s.twinklePhase) * 0.3
          );

          ctx.beginPath();
          ctx.arc(s.x, s.y, s.radius, 0, Math.PI * 2);
          ctx.fillStyle = s.color;
          ctx.globalAlpha = currentAlpha;
          ctx.shadowColor = s.color;
          ctx.shadowBlur = s.radius > 1.2 ? 6 : 0;
          ctx.fill();
        });

        // Render shooting stars
        ctx.shadowBlur = 0;
        shootingStars = shootingStars.filter((ss) => ss.opacity > 0.01);
        shootingStars.forEach((ss) => {
          ctx.beginPath();
          const tailX = ss.x - Math.cos(ss.angle) * ss.len;
          const tailY = ss.y - Math.sin(ss.angle) * ss.len;

          const starGrad = ctx.createLinearGradient(tailX, tailY, ss.x, ss.y);
          starGrad.addColorStop(0, 'rgba(255, 255, 255, 0)');
          starGrad.addColorStop(0.7, `rgba(192, 132, 252, ${ss.opacity * 0.7})`);
          starGrad.addColorStop(1, `rgba(255, 255, 255, ${ss.opacity})`);

          ctx.strokeStyle = starGrad;
          ctx.lineWidth = 1.6;
          ctx.lineCap = 'round';
          ctx.moveTo(tailX, tailY);
          ctx.lineTo(ss.x, ss.y);
          ctx.stroke();

          ss.x += Math.cos(ss.angle) * ss.speed;
          ss.y += Math.sin(ss.angle) * ss.speed;
          ss.opacity -= 0.02;
        });
      }

      ctx.globalAlpha = 1;
      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
      clearInterval(shootInterval);
      window.removeEventListener('resize', handleResize);
    };
  }, [mode]);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden bg-[#07080d]">
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full block" />
      <div className="absolute inset-0 bg-radial from-transparent via-[#07080d]/40 to-[#07080d]/90 pointer-events-none" />
    </div>
  );
}
