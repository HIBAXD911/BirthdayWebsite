/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import CosmicBackground from './components/CosmicBackground';
import PrologueEnvelope from './components/PrologueEnvelope';
import ConstellationMemories from './components/ConstellationMemories';
import ReasonsWhyYouAreRare from './components/ReasonsWhyYouAreRare';
import BirthdayCakeCeremony from './components/BirthdayCakeCeremony';
import HeartfeltLetter from './components/HeartfeltLetter';
import GiftUnboxModal from './components/GiftUnboxModal';
import NavigationDock from './components/NavigationDock';
import CustomizeModal from './components/CustomizeModal';
import { ChapterId, GreetingConfig, MemoryItem } from './types';
import { PARTNER_PRESET } from './data/presets';
import { soundEngine } from './utils/audio';
import { generateStandaloneHtml } from './utils/exportHtml';

export default function App() {
  const [config, setConfig] = useState<GreetingConfig>(PARTNER_PRESET);
  const [activeChapter, setActiveChapter] = useState<ChapterId>('gateway');
  const [isAudioMuted, setIsAudioMuted] = useState(false);
  const [isCustomizeOpen, setIsCustomizeOpen] = useState(false);
  const [bgMode, setBgMode] = useState<'celestial' | 'neon-stars'>('celestial');

  // Initialize sound on first user gesture anywhere
  useEffect(() => {
    const handleInitialUserGesture = () => {
      soundEngine.startAmbient();
      window.removeEventListener('click', handleInitialUserGesture);
      window.removeEventListener('keydown', handleInitialUserGesture);
    };

    window.addEventListener('click', handleInitialUserGesture, { once: true });
    window.addEventListener('keydown', handleInitialUserGesture, { once: true });

    return () => {
      soundEngine.stopAmbient();
    };
  }, []);

  const handleToggleAudio = () => {
    const muted = soundEngine.toggleMute();
    setIsAudioMuted(muted);
  };

  const handleAddMemory = (newMem: MemoryItem) => {
    setConfig((prev) => ({
      ...prev,
      memories: [newMem, ...prev.memories],
    }));
  };

  const handleDownloadStandaloneHtml = () => {
    const htmlContent = generateStandaloneHtml(config);
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `happy-birthday-${config.recipientName.toLowerCase().replace(/\s+/g, '-')}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="relative min-h-screen text-slate-100 selection:bg-purple-500/30 selection:text-purple-200 overflow-x-hidden font-sans-clean">
      {/* Dynamic Cosmic Background */}
      <CosmicBackground mode={bgMode} />

      {/* Main Content Area */}
      <main className="relative z-10 pb-28 pt-4 sm:pt-8 min-h-screen flex flex-col justify-between">
        <AnimatePresence mode="wait">
          {activeChapter === 'gateway' && (
            <motion.div
              key="gateway"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.5 }}
            >
              <PrologueEnvelope
                config={config}
                onOpen={() => setActiveChapter('constellation')}
                isAudioMuted={isAudioMuted}
                onToggleAudio={handleToggleAudio}
              />
            </motion.div>
          )}

          {activeChapter === 'constellation' && (
            <motion.div
              key="constellation"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.5 }}
            >
              <ConstellationMemories
                memories={config.memories}
                recipientName={config.recipientName}
                onNext={() => setActiveChapter('reasons')}
                onAddMemory={handleAddMemory}
              />
            </motion.div>
          )}

          {activeChapter === 'reasons' && (
            <motion.div
              key="reasons"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.5 }}
            >
              <ReasonsWhyYouAreRare
                reasons={config.reasons}
                recipientName={config.recipientName}
                relationship={config.relationship}
                onNext={() => setActiveChapter('cake')}
              />
            </motion.div>
          )}

          {activeChapter === 'cake' && (
            <motion.div
              key="cake"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.5 }}
            >
              <BirthdayCakeCeremony
                recipientName={config.recipientName}
                wishingStarDefault={config.wishingStarDefault}
                onNext={() => setActiveChapter('letter')}
              />
            </motion.div>
          )}

          {activeChapter === 'letter' && (
            <motion.div
              key="letter"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.5 }}
            >
              <HeartfeltLetter
                config={config}
                onNext={() => setActiveChapter('gift')}
              />
            </motion.div>
          )}

          {activeChapter === 'gift' && (
            <motion.div
              key="gift"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.5 }}
            >
              <GiftUnboxModal
                config={config}
                onRestart={() => setActiveChapter('gateway')}
                onOpenCustomize={() => setIsCustomizeOpen(true)}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Minimal Subtle Brand / Year Watermark */}
        <footer className="text-center text-[11px] text-slate-500 py-6">
          <span>Crafted with devotion &bull; 2026 Interactive Experience</span>
        </footer>
      </main>

      {/* Floating Navigation & Controls Dock */}
      <NavigationDock
        activeChapter={activeChapter}
        onSelectChapter={(chap) => setActiveChapter(chap)}
        isAudioMuted={isAudioMuted}
        onToggleAudio={handleToggleAudio}
        onOpenCustomize={() => setIsCustomizeOpen(true)}
        onDownloadHtml={handleDownloadStandaloneHtml}
        bgMode={bgMode}
        onToggleBgMode={() => setBgMode((prev) => (prev === 'celestial' ? 'neon-stars' : 'celestial'))}
      />

      {/* Personalization & Single HTML Export Modal */}
      <CustomizeModal
        config={config}
        isOpen={isCustomizeOpen}
        onClose={() => setIsCustomizeOpen(false)}
        onUpdateConfig={(newConfig) => setConfig(newConfig)}
      />
    </div>
  );
}
