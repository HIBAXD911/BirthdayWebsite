import { GreetingConfig } from '../types';

export const PARTNER_PRESET: GreetingConfig = {
  recipientName: 'Seif',
  senderName: 'With all my heart, 🤍',
  relationship: 'partner',
  nickname: 'My Favorite Idiot 🤍',
  birthdayDate: 'Today & Forever',
  ageDisplay: 'Another Year of You Being Extraordinary',
  letter: {
    salutation: 'Happy birthday to the person who somehow became one of the most important people in my life. 🤍',
    paragraphs: [
      'There is something deeply rare about the way the world moves when you are near. In a universe of billions of people and fleeting moments, finding you feels less like luck and more like returning home.',
      'You have this way of making even the most ordinary nights feel special. The late-night conversations, the hours spent playing together, laughing until we couldn\'t breathe, sharing funny moments and random stories, and those moments where neither of us wanted to go to sleep because we just wanted to keep talking.',
      'What means the most to me is the way you care. You listen when I need someone, you notice when something is wrong, you worry about me, and you\'re always there for me. Even the fact that you stay up at night just to talk to me means more than you probably realize.',
      'Somewhere between all those late nights, stupid jokes, random conversations, games, laughter, and little moments, you became someone incredibly special to me. You\'re not just someone I happen to talk to online anymore. You\'re someone I genuinely look forward to every day. Someone whose presence can change my entire mood without even trying.',
      'And honestly, I don\'t know exactly what we are or where all of this is going. Maybe that\'s what makes it so beautiful. There are things I can\'t really put into words, feelings I don\'t always know how to explain, but I hope you can feel them in all the little ways I care about you.',
      'I hope you know that you are appreciated more than you realize, cared about more than I probably say, and that having you in my life has become something I never want to take for granted.',
      'Happy birthday, idiot. 🤍 I hope this year brings you every bit of happiness, love, and warmth that you deserve. And I hope we get many more nights of staying up way too late, playing together, laughing at absolutely nothing, sharing silly funny moments, and making memories that we\'ll look back on someday and smile about.',
      'I\'m really, really glad I found you. 🤍'
    ],
    closing: 'Forever & hopelessly yours,',
    postScript: 'P.S. You are still stuck with me for all the late-night calls, game sessions, and funny daily moments. 🤍'
  },
  memories: [
    {
      id: 'm1',
      title: 'Late Night Calls & Conversations',
      subtitle: 'Where neither of us wanted to sleep',
      date: 'Every 2 AM moment',
      tag: 'Late-Night Magic',
      note: 'Those endless hours talking quietly into the night, whispering and laughing until 3 AM, and that gentle feeling where neither of us ever wanted to hang up the call.',
      imageUrl: '/assets/glowing_purple_lilies.jpg',
      iconName: 'Moon'
    },
    {
      id: 'm2',
      title: 'Listening to Each Other',
      subtitle: 'Noticing when something is wrong',
      date: 'Safe Sanctuary',
      tag: 'Quiet Care',
      note: 'You listen when I need someone, you notice when something is off before I even speak, and you genuinely care and worry about me. You make me feel completely safe.',
      imageUrl: '/assets/crescent_moon_star.jpg',
      iconName: 'HeartHandshake'
    },
    {
      id: 'm3',
      title: 'Laughing Until We Couldn\'t Breathe',
      subtitle: 'Stupid jokes & uncontrollable giggles',
      date: 'Pure Happiness',
      tag: 'Unfiltered Us',
      note: 'Laughing at absolutely nothing, stupid jokes that make no sense to anyone else, wheezing and holding our stomachs until our cheeks hurt.',
      imageUrl: '/assets/purple_roses_cathedral.jpg',
      iconName: 'Smile'
    },
    {
      id: 'm4',
      title: 'Watching Together Across Distance',
      subtitle: 'Synchronized screens & running commentary',
      date: 'Movie Nights',
      tag: 'Together Anywhere',
      note: 'Counting down \'3, 2, 1, play\', pausing to gasp or rant, tossing commentary back and forth, and making even the worst movies the most fun experience.',
      imageUrl: '/assets/purple_moon_wildflowers.jpg',
      iconName: 'Tv'
    },
    {
      id: 'm5',
      title: 'Playing Games for Hours Together',
      subtitle: 'Our chaotic & unstoppable duo',
      date: 'Victory & Fun',
      tag: 'Gaming Nights',
      note: 'The hours spent playing together, clutching impossible rounds, roasting each other\'s gameplay, and celebrating every small victory as a team.',
      imageUrl: '/assets/glowing_purple_lilies.jpg',
      iconName: 'Gamepad2'
    },
    {
      id: 'm6',
      title: 'Sharing Our Funniest & Random Moments',
      subtitle: 'Inside jokes & laughing till our cheeks hurt',
      date: 'The Fun Debrief',
      tag: 'Funny Moments',
      note: 'Spilling every funny little detail of the day, telling each other hilarious stories, and cracking up together knowing that you listen to every single word.',
      imageUrl: '/assets/crescent_moon_star.jpg',
      iconName: 'MessageCircle'
    },
    {
      id: 'm7',
      title: 'Being the Best Part of My Day',
      subtitle: 'Someone whose presence changes everything',
      date: 'Every Single Day',
      tag: 'My Favorite Person',
      note: 'No matter how stressful, boring, or tiring the day gets, seeing your name pop up or getting on call with you instantly resets my whole mood.',
      imageUrl: '/assets/purple_moon_wildflowers.jpg',
      iconName: 'Sun'
    },
    {
      id: 'm8',
      title: 'Falling In Love More Each Passing Day',
      subtitle: 'A quiet, unstoppable feeling',
      date: 'Every Passing Day',
      tag: 'Growing Deeper',
      note: 'Between every late-night conversation, every shared secret, every silly laugh, and every thoughtful gesture, I find myself falling for you more and more.',
      imageUrl: '/assets/purple_roses_cathedral.jpg',
      iconName: 'Heart'
    },
    {
      id: 'm9',
      title: 'Appreciating Every Single Moment',
      subtitle: 'Something I will never take for granted',
      date: 'Today & Always',
      tag: 'Core Memory',
      note: 'Finding someone like you in this huge world feels like a miracle. I appreciate every second we spend together, and I hold each memory so close.',
      imageUrl: '/assets/gothic_purple_banner.jpg',
      iconName: 'Sparkles'
    }
  ],
  reasons: [
    {
      id: 'r1',
      number: '01',
      title: 'How You Stay Up Late With Me',
      detail: 'Sacrificing sleep just to keep talking, keep me company, and make sure I feel loved and never alone at night.',
      category: 'Devotion',
      icon: 'Moon'
    },
    {
      id: 'r2',
      number: '02',
      title: 'The Way You Notice Everything',
      detail: 'You notice when something is wrong before I even say it. You worry about me, listen to me, and care with your whole heart.',
      category: 'Empathy',
      icon: 'ShieldHeart'
    },
    {
      id: 'r3',
      number: '03',
      title: 'Your Belly-Aching, Unfiltered Laugh',
      detail: 'Laughing together until we can\'t breathe is genuinely my favorite sound in the galaxy. Nothing makes me happier.',
      category: 'Pure Joy',
      icon: 'Smile'
    },
    {
      id: 'r4',
      number: '04',
      title: 'How You Listen to All My Day Details',
      detail: 'From the biggest achievements to the funniest random stories and thoughts, you genuinely listen and care about all of it.',
      category: 'Sanctuary',
      icon: 'Home'
    },
    {
      id: 'r5',
      number: '05',
      title: 'The Best Part of My Entire Day',
      detail: 'You have this effortless ability to change my entire mood without even trying. Just hearing from you makes the world brighter.',
      category: 'Magic',
      icon: 'Sun'
    },
    {
      id: 'r6',
      number: '06',
      title: 'My Favorite Idiot, Always',
      detail: 'The stupid jokes, the teasing, the inside moments—you\'re my person, and I wouldn\'t trade you for the world.',
      category: 'Forever',
      icon: 'Heart'
    }
  ],
  coupons: [
    {
      id: 'c1',
      title: 'Late-Night All-Nighter Call Pass',
      desc: 'Redeemable anytime: We stay up until 4 AM talking, laughing, playing, or falling asleep on call together.',
      tag: 'Late Night',
      icon: 'Moon'
    },
    {
      id: 'c2',
      title: 'Day Details & Funny Moments Debrief',
      desc: 'Redeemable anytime: Sharing all the funniest stories, every tiny detail of your day, zero interruptions, 100% undivided attention.',
      tag: 'VIP Chat',
      icon: 'PhoneCall'
    },
    {
      id: 'c3',
      title: 'Unrestricted Gaming Duo Pass',
      desc: 'Redeemable anytime: Hours of playing our favorite games together, me backing you up and celebrating every clutch.',
      tag: 'Gaming Duo',
      icon: 'Award'
    },
    {
      id: 'c4',
      title: 'You Don\'t Have to Be Strong Pass',
      desc: 'Redeemable when exhausted: A safe space to vent, complain, or be quiet. I listen, worry about you, and comfort you.',
      tag: 'Comfort',
      icon: 'HeartHandshake'
    },
    {
      id: 'c5',
      title: 'Watch Party Priority Movie Pick',
      desc: 'Redeemable anytime: You pick whatever show or movie we watch, snacks ready, with live reactions.',
      tag: 'Movie Night',
      icon: 'Car'
    },
    {
      id: 'c6',
      title: 'Win Any Friendly Argument Pass',
      desc: 'Redeemable once: You are legally, indisputably declared 100% right. No counter-arguments permitted!',
      tag: 'Immunity',
      icon: 'Key'
    }
  ],
  secretCodeMessage: 'Somewhere between all those late nights and stupid jokes, you became the best part of my life. Happy birthday, idiot. 🤍',
  wishingStarDefault: 'May this year bring you every bit of happiness, love, and warmth that you deserve. 🤍'
};

export const CRUSH_PRESET: GreetingConfig = {
  recipientName: 'Someone Unforgettable',
  senderName: 'From someone who admires you endlessly',
  relationship: 'crush',
  nickname: 'The Brightest Star',
  birthdayDate: 'A Very Special Day',
  ageDisplay: 'Happy Birthday, Beautiful Mind',
  letter: {
    salutation: 'Hey you,',
    paragraphs: [
      'I wanted to make something for you that was as thoughtful, distinct, and wonderful as you are. Today is a celebration of the day the world got a whole lot brighter because you entered it.',
      'I do not know if you realize the kind of energy you bring with you — the effortless poise, the genuine smile that catches people off guard, and the quiet warmth that makes anyone lucky enough to talk with you want to stay in the conversation longer.',
      'I hope this year brings you all the dreams you secretly whisper to the stars. May you be surrounded by good music, good people, and moments that take your breath away.'
    ],
    closing: 'Thinking of you today,',
    postScript: 'P.S. I really hope this made you smile today — you deserve the brightest one.'
  },
  memories: [
    {
      id: 'cm1',
      title: 'The First Time We Actually Talked',
      subtitle: 'When an ordinary day turned electric',
      date: 'Instant spark',
      tag: 'Beginning',
      note: 'I remember walking away thinking: wow, this person is completely different from anyone else. Your humor, your quick wit, your effortless charm.',
      imageUrl: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?auto=format&fit=crop&w=800&q=80',
      iconName: 'Sparkles'
    },
    {
      id: 'cm2',
      title: 'When You Smiled at My Joke',
      subtitle: 'The highlight of my whole week',
      date: 'Small moment, huge impact',
      tag: 'Treasured',
      note: 'I tried to play it cool, but honestly having your attention and seeing you laugh was the sweetest feeling.',
      imageUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80',
      iconName: 'Heart'
    },
    {
      id: 'cm3',
      title: 'Your Taste in Music & Books',
      subtitle: 'Every recommendation is gold',
      date: 'Shared playlists',
      tag: 'Connection',
      note: 'Every time you send a song or mention something you love, I pay attention. You have such an effortlessly cool perspective on life.',
      imageUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80',
      iconName: 'Music'
    },
    {
      id: 'cm4',
      title: 'The Next Adventure Awaiting Us',
      subtitle: 'Hoping for many more chapters',
      date: 'To the future',
      tag: 'Wishful',
      note: 'Here is to more coffee runs, more conversations that stretch way too late, and getting to know every side of your story.',
      imageUrl: 'https://images.unsplash.com/photo-1470240731273-7821a6eeb6bd?auto=format&fit=crop&w=800&q=80',
      iconName: 'Compass'
    }
  ],
  reasons: [
    {
      id: 'cr1',
      number: '01',
      title: 'Your Effortless Glow',
      detail: 'You don’t even have to try. The way you carry yourself is naturally magnetic and captivating.',
      category: 'Aura',
      icon: 'Sun'
    },
    {
      id: 'cr2',
      number: '02',
      title: 'Your Infectious Laughter',
      detail: 'You have that rare, genuine laugh that makes everyone in the vicinity turn and smile.',
      category: 'Charm',
      icon: 'Smile'
    },
    {
      id: 'cr3',
      number: '03',
      title: 'The Way You Notice Details',
      detail: 'You remember the smallest things people mention in passing. That attentiveness is breathtaking.',
      category: 'Grace',
      icon: 'Sparkles'
    },
    {
      id: 'cr4',
      number: '04',
      title: 'Your Mysterious Coolness',
      detail: 'There’s an intriguing depth to your thoughts. Every conversation leaves me wanting to know you more.',
      category: 'Mystery',
      icon: 'Moon'
    },
    {
      id: 'cr5',
      number: '05',
      title: 'Your Kind Eyes',
      detail: 'Whenever you look at someone speaking, you give them your full attention. It’s impossible not to notice.',
      category: 'Warmth',
      icon: 'Heart'
    },
    {
      id: 'cr6',
      number: '06',
      title: 'Just Being Exactly Who You Are',
      detail: 'In a world where so many people imitate, your authenticity is pure, refreshing magic.',
      category: 'Realness',
      icon: 'Stars'
    }
  ],
  coupons: [
    {
      id: 'cc1',
      title: 'Coffee or Boba On Me',
      desc: 'Redeemable anytime: Your favorite drink, anywhere you pick, my treat.',
      tag: 'Hangout',
      icon: 'Coffee'
    },
    {
      id: 'cc2',
      title: 'Aux Cord DJ Privilege',
      desc: 'Complete control of the music queue on our next drive or hangout session.',
      tag: 'Music',
      icon: 'Music'
    },
    {
      id: 'cc3',
      title: 'Secret Story Share',
      desc: 'Ask me anything you want and I will answer with complete, unedited honesty.',
      tag: 'Truth',
      icon: 'Key'
    },
    {
      id: 'cc4',
      title: 'One Wish On Demand',
      desc: 'Ask for a favor, an errand, or moral support whenever you need an ally.',
      tag: 'Anytime',
      icon: 'Sparkles'
    }
  ],
  secretCodeMessage: 'You take my breath away every single time.',
  wishingStarDefault: 'May this year bring someone who loves you with the depth you deserve.'
};

export const BEST_FRIEND_PRESET: GreetingConfig = {
  recipientName: 'Partner in Chaos',
  senderName: 'Your Ride or Die Bestie',
  relationship: 'best_friend',
  nickname: 'My Main Character',
  birthdayDate: 'National Bestie Holiday',
  ageDisplay: 'Leveling Up In Pure Greatness',
  letter: {
    salutation: 'To my undisputed favorite human,',
    paragraphs: [
      'Happy birthday to the person who knows all my secrets, judges the same people with me using only eye contact, and has made life ten thousand times funnier and brighter.',
      'Through every dramatic crisis, terrible decision, hilarious 2 AM breakdown, and triumphant victory, you have been right beside me. True friendship like ours is so hard to find, and I will never take you for granted.',
      'This year is YOUR year. You are going to achieve every goal you’ve set, outshine every obstacle, and stay the most iconic, hilarious, and irreplaceable person on this planet.'
    ],
    closing: 'Your friend for life & beyond,',
    postScript: 'P.S. We are going to be causing trouble together in retirement homes, guaranteed.'
  },
  memories: [
    {
      id: 'bm1',
      title: 'The 2 AM Voice Note Sagas',
      subtitle: '15-minute unhinged podcasts',
      date: 'Nightly rituals',
      tag: 'Iconic',
      note: 'Debriefing about our days, analyzing texts, laughing until our eyes water. Nobody gets me like you do.',
      imageUrl: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=800&q=80',
      iconName: 'MessageCircle'
    },
    {
      id: 'bm2',
      title: 'Surviving That Chaos Together',
      subtitle: 'Should have been a sitcom episode',
      date: 'Unfiltered lore',
      tag: 'Survival',
      note: 'When everything went sideways and we just looked at each other and couldn’t stop laughing hysterically.',
      imageUrl: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=800&q=80',
      iconName: 'Flame'
    },
    {
      id: 'bm3',
      title: 'Late Night Fast Food Feasts',
      subtitle: 'Eating in the parked car',
      date: 'Comfort traditions',
      tag: 'Sanctuary',
      note: 'Parking lot deep chats with fries on the dashboard while talking about our future dreams and conspiracy theories.',
      imageUrl: 'https://images.unsplash.com/photo-1527529482837-4698179dc6ce?auto=format&fit=crop&w=800&q=80',
      iconName: 'Pizza'
    },
    {
      id: 'bm4',
      title: 'Our Spontaneous Adventures',
      subtitle: 'Saying yes to terrible plans',
      date: 'Core memories',
      tag: 'Adventures',
      note: 'No plan, zero battery, 100% confidence. With you, even getting lost turns into the best memory of the month.',
      imageUrl: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=800&q=80',
      iconName: 'Zap'
    }
  ],
  reasons: [
    {
      id: 'br1',
      number: '01',
      title: 'Telepathic Communication',
      detail: 'We can literally communicate entire paragraphs with one eyebrow twitch in a room full of people.',
      category: 'Superpower',
      icon: 'Eye'
    },
    {
      id: 'br2',
      number: '02',
      title: 'Zero Judgment Zone',
      detail: 'I can tell you the most embarrassing, unhinged thought and know you will only laugh and hype me up.',
      category: 'Loyalty',
      icon: 'Shield'
    },
    {
      id: 'br3',
      number: '03',
      title: 'Your Unstoppable Loyalty',
      detail: 'If anyone ever wronged me, I know you’d be ready to show up with snacks, alibis, and pitchforks.',
      category: 'Ride or Die',
      icon: 'Flame'
    },
    {
      id: 'br4',
      number: '04',
      title: 'You Are Unapologetically You',
      detail: 'Your humor, your taste, your confidence — you never fake it for anyone. You are 100% genuine.',
      category: 'Iconic',
      icon: 'Sparkles'
    },
    {
      id: 'br5',
      number: '05',
      title: 'The Ultimate Hype Person',
      detail: 'Nobody gasses me up like you do before a big day, interview, or outfit test. You believe in me even when I doubt myself.',
      category: 'Bestie',
      icon: 'Heart'
    },
    {
      id: 'br6',
      number: '06',
      title: 'Always Showing Up',
      detail: 'No matter how busy life gets, you pick up the phone and it feels like no time has passed at all.',
      category: 'Forever',
      icon: 'Stars'
    }
  ],
  coupons: [
    {
      id: 'bc1',
      title: 'Emergency Vent Session',
      desc: 'Available 24/7. Immediate delivery of snacks, hilarious memes, and unconditional validation.',
      tag: 'Rescue',
      icon: 'PhoneCall'
    },
    {
      id: 'bc2',
      title: 'Full Day Bestie Outing',
      desc: 'Thrifting, coffee, eating delicious food, zero responsibilities, totally on me.',
      tag: 'Fun',
      icon: 'Gift'
    },
    {
      id: 'bc3',
      title: 'Personal Photographer Pass',
      desc: 'I will take 200 candid aesthetic photos of you from all angles until we get the perfect post.',
      tag: 'Hype',
      icon: 'Camera'
    },
    {
      id: 'bc4',
      title: 'Get Out of Any Social Event Pass',
      desc: 'Fake phone call emergency to rescue you from any awkward dinner or terrible date.',
      tag: 'Secret Weapon',
      icon: 'ShieldAlert'
    }
  ],
  secretCodeMessage: 'There is literally no one in the world like you. Proud of you always!',
  wishingStarDefault: 'May you get everything you deserve this year, which is literally the whole world.'
};
